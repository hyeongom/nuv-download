(() => {
  const version = chrome.runtime.getManifest().version;
  const previous = globalThis.NuvPlayerController;
  if (previous?.version === version && previous.active) return;
  previous?.dispose();
  let disposed = false;
  const actions = {
    BrowserYouTubeMute: 'YouTube', BrowserYouTubeNext: 'YouTube', BrowserYouTubePrevious: 'YouTube',
    BrowserNetflixPreviousEpisode: 'Netflix', BrowserNetflixNextEpisode: 'Netflix',
    BrowserNetflixMute: 'Netflix', BrowserNetflixSkipIntro: 'Netflix', BrowserDisneyMute: 'Disney+', BrowserDisneySkipIntro: 'Disney+'
  };
  const service = { 'www.youtube.com': 'YouTube', 'www.netflix.com': 'Netflix', 'www.disneyplus.com': 'Disney+' }[location.hostname];
  const seen = previous?.seen || new Set();
  const pendingEpisodes = new Map();
  // Older controllers recorded attempts as success. Do not inherit those false positives.
  const autoHistory = previous?.autoStateVersion === 4 ? previous.autoHistory : new Set();
  // Pre-actionability controllers could exhaust attempts before the UI appeared.
  // Keep confirmed successes, but drop those failed attempts once on migration.
  const autoAttempts = previous?.autoStateVersion === 4 && previous?.autoAttemptVersion === 1 ? previous.autoAttempts : new Map();
  let autoNotBefore = previous?.autoStateVersion === 4 ? previous.autoNotBefore || 0 : 0;
  let autoLastTime = previous?.autoStateVersion === 4 ? previous.autoLastTime ?? null : null;
  let autoSessionKey = previous?.autoSessionKey || '';
  let autoTimer = null, autoObserver = null, autoChecking = false, autoCheckPending = false;
  let autoPointerFrame = null, autoPointerAt = -Infinity;
  let autoAnimationFrame = null;
  const autoSeeks = new Map();
  let youtubeAd = null;
  const visible = element => !!element && !element.disabled && element.getAttribute('aria-disabled') !== 'true' &&
    element.getClientRects().length > 0 && getComputedStyle(element).visibility !== 'hidden' && getComputedStyle(element).display !== 'none';
  function actionableSkip(button) {
    if (!visible(button) || !button.isConnected) return false;
    // pointer-events/visibility inherit, but a child can explicitly override
    // them. Read the button's computed value, not every ancestor's value.
    if (getComputedStyle(button).pointerEvents === 'none' || getComputedStyle(button).visibility === 'collapse') return false;
    // A player may keep old/transparent controls in the DOM with a full-size
    // rectangle. Do not spend the bounded click attempts on that hidden UI.
    for (let element = button; element; element = element.parentElement) {
      const style = getComputedStyle(element);
      if (style.display === 'none' || style.opacity === '0') return false;
    }
    return true;
  }
  const currentSkipButton = kind => [...document.querySelectorAll('button, [role="button"]')]
    .find(button => skipKind(button) === kind && actionableSkip(button));
  function youtubeAdControl() {
    if (service !== 'YouTube' || !/^\/(watch(?:\/|$)|embed\/)/.test(location.pathname)) return null;
    const videos = [...document.querySelectorAll('video')].filter(visible);
    if (videos.length !== 1) return null;
    const video = videos[0], player = video.closest?.('.html5-video-player');
    if (!player?.classList.contains('ad-showing')) return null;
    // Only YouTube's skip-ad controls inside the active ad player. Never match
    // arbitrary text, advertiser links, dismiss controls, or next-video buttons.
    const button = [...player.querySelectorAll('.ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-skip-ad-button')]
      .find(b => b.matches('button, [role="button"]') && b.closest('.html5-video-player') === player && actionableSkip(b));
    return {video, player, button};
  }
  async function runYouTubeAdSkip(followup) {
    if (autoChecking) { autoCheckPending = true; return; }
    autoCheckPending = false;
    const control = youtubeAdControl();
    if (!control) { youtubeAd = null; return; }
    const {video, player, button} = control, url = location.href, source = video.currentSrc;
    // The same DOM button can be reused for the next ad. Reset at a new media
    // source, player, watch URL, or backwards ad timeline, not just on UI hiding.
    if (!youtubeAd || youtubeAd.video !== video || youtubeAd.player !== player || youtubeAd.url !== url ||
        youtubeAd.source !== source || video.currentTime < youtubeAd.time - 0.5)
      youtubeAd = {video, player, url, source, time:video.currentTime, count:0, at:0};
    const state = youtubeAd;
    state.time = video.currentTime;
    if (!button || video.paused || video.ended || video.seeking || video.readyState < 2 ||
        state.count >= 3 || (state.count && Date.now()-state.at < 250)) return;
    autoChecking = true;
    try {
      const permit = await chrome.runtime.sendMessage({type:'nuv-auto-skip-check', kind:'ad', expectedUrl:url});
      const live = youtubeAdControl();
      if (disposed || !live?.button || live.video !== video || live.player !== player || youtubeAd !== state ||
          location.href !== url || video.currentSrc !== source || video.currentTime < state.time - 0.5 ||
          video.paused || video.ended || video.seeking || video.readyState < 2 ||
          permit?.allowed !== true || permit.kind !== 'ad' || permit.expectedUrl !== url ||
          !Number.isSafeInteger(permit.expiresAt) || permit.expiresAt <= Date.now() || permit.expiresAt > Date.now()+1500) return;
      state.count++; state.at = Date.now();
      live.button.click();
    } catch { /* A disconnected or unready player is checked on its next event. */ }
    finally {
      autoChecking = false;
      if (autoCheckPending && !followup && !disposed) { autoCheckPending=false; void runAutoSkip(true); }
    }
  }
  function exactSkipButton(action) {
    if (action === 'BrowserNetflixSkipIntro') {
      const known = [...document.querySelectorAll('button[data-uia="player-skip-intro"], [data-uia="player-skip-intro"] button')].find(visible);
      if (known) return known;
    }
    // Exact visible labels only: never click ads, next episode, login or purchase buttons.
    const labels = action === 'BrowserNetflixSkipIntro'
      ? ['오프닝 건너뛰기', '줄거리 건너뛰기', '지난 이야기 건너뛰기', 'Skip Intro', 'Skip Recap']
      : ['오프닝 건너뛰기', '지난 이야기 건너뛰기', 'Skip Intro', 'Skip Recap'];
    return [...document.querySelectorAll('button, [role="button"]')].find(button => visible(button) &&
      labels.some(label => [button.textContent, button.getAttribute('aria-label')].some(text => text?.replace(/\s+/g, ' ').trim().toLowerCase() === label.toLowerCase())));
  }
  function skipKind(button) {
    // Netflix can reuse its skip-intro control for the recap. The displayed label
    // determines which preference and completion record apply, not that control ID.
    for (const text of [button.textContent, button.getAttribute('aria-label')]) {
      const label = text?.replace(/\s+/g, ' ').trim().toLowerCase();
      if (['오프닝 건너뛰기','skip intro'].includes(label)) return 'intro';
      if (['줄거리 건너뛰기','지난 이야기 건너뛰기','skip recap'].includes(label)) return 'recap';
    }
    const uia = button.getAttribute('data-uia');
    if (service === 'Netflix' && uia === 'player-skip-intro') return 'intro';
    if (service === 'Netflix' && uia === 'player-skip-recap') return 'recap';
    return null;
  }
  function revealSkipControls(video) {
    if (service !== 'Netflix' || !video?.dispatchEvent || !video.getBoundingClientRect) return false;
    const surface = video.closest('.watch-video') || document.querySelector('.watch-video--player-view');
    const rect = video.getBoundingClientRect();
    const x = rect.left + rect.width / 2, y = rect.top + rect.height / 2;
    const overlay = document.elementFromPoint(x, y);
    const targets = new Set([video, surface?.querySelector('[data-uia="player"]'),
      surface && overlay && surface.contains(overlay) ? overlay : null, surface]);
    for (const target of targets) {
      if (!target || !visible(target)) continue;
      for (const type of ['pointerover','pointermove','mouseover','mousemove']) {
        const options = { bubbles: true, composed: true, view: window, clientX: x, clientY: y, buttons: 0 };
        target.dispatchEvent(type.startsWith('pointer')
          ? new PointerEvent(type, { ...options, pointerId: 1, pointerType: 'mouse', isPrimary: true })
          : new MouseEvent(type, options));
      }
    }
    return true;
  }
  async function manualSkip(message, video, state) {
    const source = video.currentSrc;
    const live = () => !disposed && !state.cancelled && Date.now() < message.expiresAt &&
      location.href === message.expectedUrl && video.isConnected && video.currentSrc === source;
    const wait = () => new Promise(resolve => setTimeout(resolve, 50));
    // A hidden Netflix overlay can remove its skip button completely. Recreate
    // it on explicit key press, then resolve the current DOM rather than a cache.
    for (let i = 0; i < 16 && live(); i++) {
      if (i % 4 === 0 && revealSkipControls(video)) await wait();
      if (!live()) break;
      const videos = [...document.querySelectorAll('video')].filter(visible);
      if (videos.length !== 1 || videos[0] !== video) return 'no_player';
      const button = exactSkipButton(message.action);
      if (visible(button) && button.isConnected) {
        const kind = skipKind(button), time = video.currentTime;
        button.click();
        if (kind) {
          refreshAutoSession(video);
          autoAttempts.set(autoKey(video, kind), { kind, time, at: Date.now(), count: 1 });
        }
        return 'ok';
      }
      await wait();
    }
    return state.cancelled || disposed ? 'disabled' : location.href !== message.expectedUrl ? 'page_changed' :
      Date.now() >= message.expiresAt ? 'expired' : 'not_available';
  }
  const autoKey = (video, kind) => location.href + '\n' + (video.currentSrc || '') + '\n' + kind;
  function refreshAutoSession(video) {
    const key = location.href + '\n' + (video.currentSrc || '');
    if (autoSessionKey !== key) { autoHistory.clear(); autoAttempts.clear(); autoSeeks.clear(); autoNotBefore = 0; autoLastTime = null; autoSessionKey = key; }
  }
  function trackPlayback(video) {
    refreshAutoSession(video);
    if (!Number.isFinite(video.currentTime)) return;
    // Re-arm only after real backward movement, not when controls hide/reappear.
    // Ignore small decoder time corrections; wait for the seek UI to settle.
    if (Number.isFinite(autoLastTime) && video.currentTime < autoLastTime - 0.5) {
      autoHistory.clear();
      autoAttempts.clear();
      autoSeeks.clear();
      autoNotBefore = Date.now() + 1000;
    }
    autoLastTime = video.currentTime;
  }
  function rememberSkip(key) {
    autoHistory.add(key);
    if (autoHistory.size > 64) autoHistory.delete(autoHistory.values().next().value);
  }
  function episodeBlocksAutoSkip() {
    // A hidden tab may deliver the episode-command reply late. Its old document
    // must not block auto skip after navigation has already reached the next one.
    return [...pendingEpisodes.values()].some(state => state.url === location.href && Date.now() < state.expiresAt);
  }
  function checkAutoSkip() { return runAutoSkip(false); }
  function checkAfterAnimationStart() {
    // A fade changes computed opacity without DOM mutations. Its start event
    // can still have opacity0; check the next rendered frame, not the end of
    // a potentially long fade. No continuous frame loop or faster idle polling.
    if (disposed || autoAnimationFrame !== null) return;
    if (typeof requestAnimationFrame !== 'function') return checkAutoSkip();
    autoAnimationFrame = requestAnimationFrame(() => {
      autoAnimationFrame = null;
      if (!disposed) void checkAutoSkip();
    });
  }
  function captureAutoSeek(event) {
    if (disposed) return;
    const video = event?.target;
    const videos = [...document.querySelectorAll('video')].filter(visible);
    if (videos.length !== 1 || videos[0] !== video) return;
    for (const [key, attempt] of autoAttempts) {
      if (key === autoKey(video, attempt.kind))
        autoSeeks.set(key, { attempt, video, source: video.currentSrc });
    }
  }
  function completeAutoSeek(event) {
    if (disposed) return;
    const video = event?.target;
    const videos = [...document.querySelectorAll('video')].filter(visible);
    if (videos.length === 1 && videos[0] === video && !video.seeking) {
      trackPlayback(video);
      for (const [key, seek] of autoSeeks) {
        if (seek.video !== video) continue;
        autoSeeks.delete(key);
        // Pin the seek to the attempt that existed when seeking began. Never
        // let a recap seek confirm an intro issued later, or another document.
        if (autoAttempts.get(key) !== seek.attempt || seek.source !== video.currentSrc ||
            key !== autoKey(video, seek.attempt.kind) || !Number.isFinite(video.currentTime) ||
            video.currentTime <= seek.attempt.time + 0.05) continue;
        rememberSkip(key);
        autoAttempts.delete(key);
        // seeked confirms the media has finished moving, including short jumps
        // and buffering. The elapsed-wall-time fallback need not hold the intro.
        autoNotBefore = 0;
      }
    }
    return checkAutoSkip();
  }
  function checkAfterUserPointer(event) {
    // CSS :hover can reveal controls without a DOM mutation. The synthetic
    // wake events above must not recursively trigger another check.
    if (disposed || !event?.isTrusted || autoPointerFrame !== null || Date.now() - autoPointerAt < 100) return;
    if (typeof requestAnimationFrame !== 'function') return;
    autoPointerFrame = requestAnimationFrame(() => {
      autoPointerFrame = null;
      autoPointerAt = Date.now();
      if (!disposed) void checkAutoSkip();
    });
  }
  async function runAutoSkip(followup) {
    if (disposed) return;
    if (service === 'YouTube') return runYouTubeAdSkip(followup);
    if (autoChecking) { autoCheckPending = true; return; }
    autoCheckPending = false;
    if (episodeBlocksAutoSkip() || !['Netflix','Disney+'].includes(service)) return;
    if (service === 'Netflix' && !/^\/watch\/\d+/.test(location.pathname)) return;
    const videos = [...document.querySelectorAll('video')].filter(visible);
    if (videos.length !== 1 || videos[0].seeking || videos[0].readyState < 2) return;
    const video = videos[0], url = location.href;
    trackPlayback(video);
    if (video.paused || video.ended) return;
    const buttons = [...document.querySelectorAll('button, [role="button"]')];
    for (const [key, attempt] of autoAttempts) {
      const elapsed = Math.max(0, (Date.now() - attempt.at) / 1000);
      const progressed = Number.isFinite(video.currentTime) && Number.isFinite(attempt.time) &&
        video.currentTime - attempt.time > elapsed * Math.max(1, video.playbackRate || 1) + 2;
      // Hiding player controls alone is not proof that playback skipped.
      if (progressed) {
        rememberSkip(key);
        autoAttempts.delete(key);
        // The next skip control may already be rendered while the preceding seek
        // is settling. Do not let that seek confirm two different skip actions.
        autoNotBefore = Date.now() + 250;
      }
    }
    if (Date.now() < autoNotBefore) return;
    const candidates = buttons.filter(b => {
      const kind = skipKind(b), key = autoKey(video, kind), attempt = autoAttempts.get(key);
      return kind && (visible(b) || service === 'Netflix') && !b.disabled && b.getAttribute('aria-disabled') !== 'true' && !autoHistory.has(key) &&
        ![...autoAttempts.values()].some(other => other.kind !== kind && Date.now() - other.at < 5000) &&
        (!attempt || (attempt.count < 3 && Date.now() - attempt.at >= 250));
    });
    if (!candidates.length) return;
    autoChecking = true;
    try {
      const considered = new Set();
      for (let button of candidates) {
      const kind = skipKind(button), key = autoKey(video, kind);
      if (considered.has(kind)) continue;
      considered.add(kind);
      const requestedTime = video.currentTime;
      let permit = await chrome.runtime.sendMessage({ type: 'nuv-auto-skip-check', kind, expectedUrl: url });
      if (permit?.allowed !== true) continue;
      if (!disposed && location.href === url && !episodeBlocksAutoSkip() && revealSkipControls(video)) {
        // Allow synchronous/microtask UI updates without a timer: background
        // tabs can throttle a nominal 50ms timeout by seconds. Async mounts are
        // picked up by the existing DOM observer/playback events/fallback poll.
        await Promise.resolve();
        if (disposed || location.href !== url || episodeBlocksAutoSkip()) return;
        button = currentSkipButton(kind);
        if (!button) continue;
        // Permission/settings may change while the overlay is being remounted.
        permit = await chrome.runtime.sendMessage({ type: 'nuv-auto-skip-check', kind, expectedUrl: url });
      }
      // Authorization crosses processes. React may replace the button during
      // that await; resolve the live actionable control at the point of use.
      button = currentSkipButton(kind);
      if (disposed || episodeBlocksAutoSkip() || permit?.allowed !== true || permit.kind !== kind || permit.expectedUrl !== url ||
          !Number.isSafeInteger(permit.expiresAt) || permit.expiresAt <= Date.now() || permit.expiresAt > Date.now() + 1500 ||
          location.href !== url || autoKey(video, kind) !== key || autoHistory.has(key) || video.paused || video.ended || video.seeking || video.readyState < 2 || video.currentTime < requestedTime - 0.5 ||
          !visible(video) || !actionableSkip(button) || skipKind(button) !== kind) continue;
      const currentVideos = [...document.querySelectorAll('video')].filter(visible);
      if (currentVideos.length !== 1 || currentVideos[0] !== video) return;
      // A click is only an attempt. Retry a temporarily unresponsive control a
      // bounded number of times, obtaining a fresh authorization for every try.
      // Expired attempts of another kind cannot claim a subsequent action's seek.
      for (const [oldKey, attempt] of autoAttempts) if (attempt.kind !== kind) autoAttempts.delete(oldKey);
      autoAttempts.set(key, { kind, at: Date.now(), time: video.currentTime,
        count: (autoAttempts.get(key)?.count || 0) + 1 });
      button.click();
      break;
      }
    } catch { /* A disconnected or replaced extension must never execute offline. */ }
    finally {
      autoChecking = false;
      // DOM/video events received during async authorization must not be lost.
      // Coalesce them into one immediate follow-up, bounded to avoid a loop if
      // a site's hover handler repeatedly mutates the same controls.
      if (autoCheckPending && !followup && !disposed) {
        autoCheckPending = false;
        void runAutoSkip(true);
      }
    }
  }
  const listener = (message, sender, respond) => {
    if (disposed) return false;
    if (sender.id === chrome.runtime.id && message?.type === 'nuv-probe-v2') {
      respond({ version, url: location.href, netflixEpisodes: service === 'Netflix' && !!globalThis.NuvNetflixEpisodes }); return false;
    }
    if (sender.id === chrome.runtime.id && message?.type === 'nuv-cancel-v2' && pendingEpisodes.has(message.id)) {
      pendingEpisodes.get(message.id).cancelled = true;
      respond({ code: 'disabled' }); return false;
    }
    if (sender.id !== chrome.runtime.id || message?.type !== 'nuv-execute-v2') return false;
    if (message.expectedUrl !== location.href) { respond({ code: 'page_changed' }); return false; }
    if (!Object.hasOwn(actions, message.action) || actions[message.action] !== service || message.service !== service ||
        !/^[0-9a-f]{32}$/.test(message.id)) { respond({ code: 'error' }); return false; }
    if (!Number.isSafeInteger(message.expiresAt) || message.expiresAt <= Date.now() || message.expiresAt > Date.now() + 5000) {
      respond({ code: 'expired' }); return false;
    }
    if (seen.has(message.id)) { respond({ code: 'duplicate' }); return false; }
    seen.add(message.id);
    if (seen.size > 128) seen.delete(seen.values().next().value);
    try {
      const videos = [...document.querySelectorAll('video')].filter(visible);
      if (videos.length !== 1) { respond({ code: 'no_player' }); return false; }
      if (message.action === 'BrowserNetflixSkipIntro' || message.action === 'BrowserDisneySkipIntro') {
        if (pendingEpisodes.size) { respond({ code: 'episode_busy' }); return false; }
        const state = { cancelled: false, url: location.href, expiresAt: message.expiresAt };
        pendingEpisodes.set(message.id, state);
        manualSkip(message, videos[0], state).then(code => respond({ code }), () => respond({ code: 'error' }))
          .finally(() => { pendingEpisodes.delete(message.id); void checkAutoSkip(); });
        return true;
      }
      if (message.action === 'BrowserNetflixPreviousEpisode' || message.action === 'BrowserNetflixNextEpisode') {
        if (!globalThis.NuvNetflixEpisodes) { respond({ code: 'no_receiver' }); return false; }
        const state = { cancelled: false, url: location.href, expiresAt: message.expiresAt };
        const steps = [];
        pendingEpisodes.set(message.id, state);
        globalThis.NuvNetflixEpisodes.execute(message.action === 'BrowserNetflixNextEpisode' ? 1 : -1, message.expiresAt, () => disposed || state.cancelled,
          step => { if (steps.length < 24) steps.push(step); })
          .then(code => respond({ code: state.cancelled ? 'disabled' : code, episodeSteps: steps }), () => respond({ code: 'error', episodeSteps: steps }))
          .finally(() => { pendingEpisodes.delete(message.id); void checkAutoSkip(); });
        return true;
      }
      if (message.action.endsWith('Mute')) videos[0].muted = !videos[0].muted;
      else {
        let button;
        if (message.action === 'BrowserYouTubeNext') button = document.querySelector('.ytp-next-button');
        else if (message.action === 'BrowserYouTubePrevious') button = document.querySelector('.ytp-prev-button');
        else button = exactSkipButton(message.action);
        if (!visible(button)) { respond({ code: 'not_available' }); return false; }
        const kind = skipKind(button);
        button.click();
        if (kind) { refreshAutoSession(videos[0]); rememberSkip(autoKey(videos[0], kind)); }
      }
      // 'ok' means DOM operation dispatched, not confirmed playback progression.
      respond({ code: 'ok' });
    } catch { respond({ code: 'error' }); }
    return false;
  };
  globalThis.NuvPlayerController = { version, seen, autoStateVersion: 4, autoAttemptVersion: 1, autoHistory, autoAttempts, get autoLastTime() { return autoLastTime; }, get autoNotBefore() { return autoNotBefore; }, get autoSessionKey() { return autoSessionKey; }, active: true, dispose() {
    this.active = false;
    disposed = true;
    for (const state of pendingEpisodes.values()) state.cancelled = true;
    pendingEpisodes.clear();
    autoSeeks.clear();
    if (autoTimer !== null) clearInterval(autoTimer);
    if (autoPointerFrame !== null) cancelAnimationFrame(autoPointerFrame);
    autoPointerFrame = null;
    if (autoAnimationFrame !== null) cancelAnimationFrame(autoAnimationFrame);
    autoAnimationFrame = null;
    autoObserver?.disconnect();
    for (const event of ['transitionstart','animationstart'])
      document.removeEventListener?.(event, checkAfterAnimationStart, true);
    for (const event of ['pointermove','mousemove','pointerover'])
      document.removeEventListener?.(event, checkAfterUserPointer, true);
    document.removeEventListener?.('playing', checkAutoSkip, true);
    document.removeEventListener?.('timeupdate', checkAutoSkip, true);
    document.removeEventListener?.('seeking', captureAutoSeek, true);
    document.removeEventListener?.('seeked', completeAutoSeek, true);
    for (const event of ['loadeddata','canplay','transitionend','animationend','DOMContentLoaded'])
      document.removeEventListener?.(event, checkAutoSkip, true);
    try { chrome.runtime.onMessage.removeListener(listener); } catch {}
  }};
  chrome.runtime.onMessage.addListener(listener);
  if (['Netflix','Disney+','YouTube'].includes(service) && typeof chrome.runtime.sendMessage === 'function') {
    autoTimer = setInterval(checkAutoSkip, 500);
    // New skip buttons can appear in a background tab whose timers are throttled.
    if (typeof MutationObserver === 'function' && document.documentElement) {
      autoObserver = new MutationObserver(() => { void checkAutoSkip(); });
      autoObserver.observe(document.documentElement, { childList: true, subtree: true, characterData: true,
        attributes: true, attributeFilter: ['aria-label','aria-disabled','disabled','hidden','class','style','data-uia'] });
    }
    document.addEventListener?.('playing', checkAutoSkip, true);
    for (const event of ['transitionstart','animationstart'])
      document.addEventListener?.(event, checkAfterAnimationStart, true);
    for (const event of ['pointermove','mousemove','pointerover'])
      document.addEventListener?.(event, checkAfterUserPointer, { capture: true, passive: true });
    document.addEventListener?.('timeupdate', checkAutoSkip, true);
    document.addEventListener?.('seeking', captureAutoSeek, true);
    document.addEventListener?.('seeked', completeAutoSeek, true);
    for (const event of ['loadeddata','canplay','transitionend','animationend','DOMContentLoaded'])
      document.addEventListener?.(event, checkAutoSkip, true);
    if (document.readyState !== 'loading') void checkAutoSkip();
  }
})();
