import { createYouTubeBackgroundControl } from './debugger-worker.js';
import { createTabFavorites } from './favorite-tabs.js';
import { ensureTabController } from './tab-controller.js';
import { sites, actions, serviceOf, selectTab, validCommand } from './router.js';

const RELEASE_CHANNEL = 'stable'; // Set by channel packager.
const DIAGNOSTICS = RELEASE_CHANNEL === 'beta';
let port = null, enabled = false, heartbeat = null, connectionTask = null;
let status = '연결 안 됨', generation = 0;
let autoSkip = {}, autoSkipStateAt = 0, autoPreparing = false;
function normalizedAutoSkip(value) {
  if (value?.protocol !== 1) return {};
  return Object.fromEntries(['netflixIntro','netflixRecap','netflixNextEpisode','disneyIntro','disneyRecap','youtubeAds','chzzkAds'].map(key => [key, value[key] === true]));
}
function autoSkipAllowed(service, kind) {
  const prefix = { Netflix: 'netflix', 'Disney+': 'disney' }[service];
  return !!port && enabled && !updateTask && !reloading && Date.now() - autoSkipStateAt < 35000 &&
    (service === 'Netflix' && kind === 'nextEpisode' ? autoSkip.netflixNextEpisode === true : service === '치지직' ? kind === 'ad' && autoSkip.chzzkAds === true : service === 'YouTube' ? kind === 'ad' && autoSkip.youtubeAds === true :
      !!prefix && ['intro','recap'].includes(kind) && autoSkip[prefix + (kind === 'intro' ? 'Intro' : 'Recap')] === true);
}
async function prepareAutoSkipTabs(wake = false) {
  if (autoPreparing) return;
  autoPreparing = true;
  try {
    for (const service of ['Netflix','Disney+','YouTube','치지직']) {
      try {
      if (!autoSkipAllowed(service, 'intro') && !autoSkipAllowed(service, 'recap') && !autoSkipAllowed(service, 'ad') && !autoSkipAllowed(service,'nextEpisode')) continue;
      const { selected = {} } = await chrome.storage.session.get('selected');
      const target = selectTab(await chrome.tabs.query({ url: sites[service] }), service, selected[service]);
      if (target.tab && enabled && port) {
        await ensureTabController(target.tab);
        if (wake && service === '치지직') await chrome.tabs.sendMessage(target.tab.id, {type:'nuv-chzzk-tab-wake'}, {frameId:0});
        if (wake && service === 'Netflix') await chrome.tabs.sendMessage(target.tab.id, {type:'nuv-netflix-autonext-wake'}, {frameId:0});
      }
      } catch { /* One unavailable site's controller must not starve other services. */ }
    }
  } catch { /* Retry on the next native heartbeat, without reloading the video. */ }
  finally { autoPreparing = false; }
}
async function authorizeAutoSkip(message, sender) {
  const denied = { allowed: false };
  const service = serviceOf(sender.url);
  const expectedUrl = message.expectedUrl;
  const epoch = generation, current = port, preferences = autoSkip;
  if (sender.id !== chrome.runtime.id || sender.frameId !== 0 || !Number.isInteger(sender.tab?.id) ||
      (sender.documentLifecycle && sender.documentLifecycle !== 'active') ||
      !service || serviceOf(expectedUrl) !== service || !autoSkipAllowed(service, message.kind)) return denied;
  const { selected = {} } = await chrome.storage.session.get('selected');
  const target = selectTab(await chrome.tabs.query({ url: sites[service] }), service, selected[service]);
  if (target.tab?.id !== sender.tab.id || target.tab.url !== expectedUrl) return denied;
  if (sender.url !== expectedUrl) {
    // Chromium retains the content script's original sender.url after pushState.
    // Confirm the current URL inside that exact document, rather than trusting
    // the supplied URL or weakening the selected-tab/connection checks.
    if (typeof sender.documentId !== 'string' || !sender.documentId) return denied;
    let probe;
    try { probe = await chrome.tabs.sendMessage(sender.tab.id, { type: 'nuv-probe-v2' }, { documentId: sender.documentId }); }
    catch { return denied; }
    if (probe?.url !== expectedUrl || probe.version !== chrome.runtime.getManifest().version) return denied;
  }
  const liveTab = await chrome.tabs.get(sender.tab.id);
  if (liveTab.url !== expectedUrl || current !== port || epoch !== generation || preferences !== autoSkip ||
      !autoSkipAllowed(service, message.kind) || episodeBlocksAutoSkip(sender.tab.id, liveTab.url)) return denied;
  return { allowed: true, kind: message.kind, expectedUrl, expiresAt: Date.now() + 1000 };
}
let lastResult = '아직 NUV에서 받은 실행 명령이 없습니다.';
const pendingEpisodes = new Map();
const chzzkCommands = new Map();
const netflixPreparing = new Map();
// Restore hidden controls only for an explicit PC command. The browser's tab-
// scoped pointer never moves the OS cursor or activates another window.
async function withNetflixControls(message, tab, target, live, execute) {
  if(message.service!=='Netflix'||!['BrowserNetflixPreviousEpisode','BrowserNetflixNextEpisode','BrowserNetflixSkipIntro'].includes(message.action)||!chrome.debugger?.attach)return execute();
  if(netflixPreparing.has(tab.id))return {code:'episode_busy'};
  const run={cancelled:false,attached:false,focus:false};netflixPreparing.set(tab.id,run);
  const current=async()=>!run.cancelled&&live()&&(await chrome.tabs.get(tab.id)).url===tab.url;
  async function limited(task,ms) {
    let timer;try{return await Promise.race([task,new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('controller_timeout')),Math.max(1,Math.min(ms,message.expiresAt-Date.now())));})]);}
    finally {clearTimeout(timer);}
  }
  const state=async()=>{
    if(!await current())throw new Error('page_changed');
    const value=await limited(chrome.tabs.sendMessage(tab.id,{type:'nuv-netflix-control-state',action:message.action},target),700);
    if(value?.url!==tab.url||value.version!==chrome.runtime.getManifest().version||!await current())throw new Error('page_changed');
    return value;
  };
  const point=value=>{
    const g=value?.geometry;if(!g)return null;
    const {left,top,width,height,viewportWidth,viewportHeight}=g;
    if(![left,top,width,height,viewportWidth,viewportHeight].every(Number.isFinite)||width!==8||height!==8||left<2||top<2||viewportWidth<200||viewportHeight<150||left+width+2>viewportWidth||top+height+2>viewportHeight)return null;
    return {x:left+width/2,y:top+height/2};
  };
  const onDetach=(source,reason)=>{if(source.tabId===tab.id){run.attached=false;run.cancelled=true;void chrome.tabs.sendMessage(tab.id,{type:'nuv-cancel-v2',id:message.id},target).catch(()=>{});if(reason==='canceled_by_user')void chrome.storage.session.set({youtubeBackgroundPaused:true});}};
  chrome.debugger.onDetach.addListener(onDetach);
  try {
    let value=await state();
    if(!value.ready||value.background) {
      if(!point(value))return {code:'not_available'};
      if((await chrome.storage.session.get('youtubeBackgroundPaused')).youtubeBackgroundPaused)return {code:'cancelled'};
      if(!await chrome.permissions.contains({permissions:['debugger']}))return {code:'not_ready'};
      try{await chrome.debugger.attach({tabId:tab.id},'1.3');run.attached=true;}catch{return {code:'debugger_busy'};}
      if(!await current())return {code:'page_changed'};
      await chrome.debugger.sendCommand({tabId:tab.id},'Emulation.setFocusEmulationEnabled',{enabled:true});run.focus=true;
      value=await state();let p=point(value);
      if(!p)return {code:'not_available'};
      // Two distinct positions also wake controls when the last virtual pointer
      // was already at the centre before the player's inactivity timer elapsed.
      for(const dx of [-2,2]) {
        if(!await current())return {code:'page_changed'};
        await chrome.debugger.sendCommand({tabId:tab.id},'Input.dispatchMouseEvent',{type:'mouseMoved',x:p.x+dx,y:p.y});
      }
      const until=Math.min(message.expiresAt-150,Date.now()+900);
      while(!value.ready&&Date.now()<until){await new Promise(r=>setTimeout(r,50));value=await state();}
      if(!value.ready)return {code:'not_available'};
    }
    if(!await current())return {code:'page_changed'};
    // Execute once. A missing reply is never an excuse to repeat a playback click.
    return await limited(execute(),message.expiresAt-Date.now());
  } catch(error) {
    void chrome.tabs.sendMessage(tab.id,{type:'nuv-cancel-v2',id:message.id},target).catch(()=>{});
    return {code:error?.message==='controller_timeout'?'expired':'page_changed'};
  } finally {
    run.cancelled=true;
    chrome.debugger.onDetach.removeListener(onDetach);
    if(run.attached){if(run.focus)try{await chrome.debugger.sendCommand({tabId:tab.id},'Emulation.setFocusEmulationEnabled',{enabled:false});}catch{}
      try{await chrome.debugger.detach({tabId:tab.id});}catch{}}
    if(netflixPreparing.get(tab.id)===run)netflixPreparing.delete(tab.id);
  }
}
function episodeBlocksAutoSkip(tabId, url) {
  return [...pendingEpisodes.values()].some(state => state.tabId === tabId && state.url === url && Date.now() < state.expiresAt);
}
let tabFavorites = null, favoriteScope = null;
const favorites = () => tabFavorites ||= createTabFavorites(chrome);
const favoriteText = code => ({ favorite_added:'현재 탭을 즐겨찾기에 등록했습니다.', favorite_removed:'즐겨찾기를 해제했습니다.',
  favorite_selected:'다음 즐겨찾기 탭으로 이동했습니다.', favorite_empty:'열려 있는 즐겨찾기 탭이 없습니다.',
  favorite_permission:'탭 즐겨찾기 켜기를 눌러 권한을 허용해주세요.', favorite_scope:'PC NUV 1.23.0 이상에 연결해주세요.',
  favorite_busy:'탭 이동 중입니다. 잠시 뒤 다시 눌러주세요.', favorite_no_tab:'일반 Chrome·Edge 탭을 선택해주세요.',
  favorite_limit:'즐겨찾기는 최대 200개입니다.', favorite_failed:'탭이 닫혔거나 이동하지 못했습니다. 다시 확인해주세요.' })[code] || resultText(code);
let diagnosticRunning = false;
let updaterProtocol = 0, nativeChannel = null, updateTask = null, updatePending = null, reloading = false;
const versionAtLeast = (actual, expected) => {
  const parts = v => String(v || '').split('.').map(Number).concat([0,0,0,0]).slice(0,4);
  const a = parts(actual), b = parts(expected);
  for (let i=0;i<4;i++) { if (a[i] !== b[i]) return a[i] > b[i]; }
  return true;
};
async function saveUpdate(status) { await chrome.storage.local.set({ extensionUpdateStatus: status }); }
async function updateExtension() {
  if (reloading) return;
  if (updateTask) return updateTask;
  updateTask = (async () => {
    try {
      const requestPort = port;
      if (!port || updaterProtocol !== 1) throw new Error('업데이트를 지원하는 최신 PC NUV에 먼저 연결해주세요.');
      if (pendingEpisodes.size) throw new Error('영상 제어가 끝난 뒤 업데이트해주세요.');
      const settings = await chrome.storage.local.get(['channel','extensionUpdateExpected']);
      if (settings.extensionUpdateExpected && !versionAtLeast(chrome.runtime.getManifest().version, settings.extensionUpdateExpected))
        throw new Error('다시 로드한 확장이 업데이트된 폴더와 다릅니다. PC NUV 설치 안내의 폴더로 다시 등록해주세요.');
      const channel = RELEASE_CHANNEL;
      if (nativeChannel !== channel) throw new Error('연결된 NUV와 업데이트 채널이 다릅니다. 다시 연결해주세요.');
      let installation;
      try {
        const response = await fetch(chrome.runtime.getURL('nuv-install.json'), { cache: 'no-store' });
        if (!response.ok) throw new Error();
        installation = await response.json();
      } catch { throw new Error('PC NUV의 설치 준비에서 안내하는 폴더를 확장으로 한 번 등록해주세요. 다운로드 ZIP 폴더는 자동 교체하지 않습니다.'); }
      if (installation.protocol !== 1 || installation.channel !== channel || !/^[0-9a-f]{32}$/.test(installation.installationId))
        throw new Error('이 확장 폴더와 연결된 NUV가 다릅니다. 해당 NUV의 설치 안내 폴더로 등록해주세요.');
      const current = port;
      if (!current || current !== requestPort || updaterProtocol !== 1 || nativeChannel !== channel) throw new Error('NUV 연결이 바뀌었습니다. 다시 연결해주세요.');
      await saveUpdate('새 버전 확인·다운로드 중… 완료될 때까지 NUV를 켜두세요.');
      const id = crypto.randomUUID().replaceAll('-', '');
      const result = await new Promise((resolve, reject) => {
        const timer = setTimeout(() => { updatePending = null; reject(new Error('업데이트 응답이 지연되었습니다. NUV에 다시 연결한 뒤 업데이트 버튼으로 상태를 확인해주세요.')); }, 100000);
        updatePending = { id, current, resolve, reject, timer };
        try { current.postMessage({ type: 'update-extension', id, installationId: installation.installationId,
          extensionVersion: chrome.runtime.getManifest().version }); }
        catch { clearTimeout(timer); updatePending = null; reject(new Error('NUV에 업데이트 요청을 보내지 못했습니다.')); }
      });
      await saveUpdate(result.message);
      if (result.code === 'updated') {
        reloading = true;
        await chrome.storage.local.set({ extensionUpdateExpected: result.version });
        setTimeout(() => chrome.runtime.reload(), 300);
      }
    } catch (error) { await saveUpdate(error?.message || '확장 업데이트에 실패했습니다. 다시 시도해주세요.'); }
  })().finally(() => { updateTask = null; });
  return updateTask;
}
function cancelUpdateRequest() {
  updaterProtocol = 0; nativeChannel = null;
  if (updatePending) {
    clearTimeout(updatePending.timer);
    updatePending.reject(new Error('NUV 연결이 끊겼습니다. 다시 연결 후 업데이트 버튼을 눌러 상태를 확인해주세요.'));
    updatePending = null;
  }
}
const episodeStages = new Set(['started','locating_controls','opening_episode_menu','episode_list_missing','episode_list_found',
  'current_episode_unclear','current_episode_found','hovering_adjacent_episode','selecting_adjacent_episode',
  'preview_play_button_missing','play_button_found','next_button_found','play_clicked','navigation_confirmed','navigation_unconfirmed','exception',
  'adjacent_row_replaced','adjacent_row_unverified','play_button_hidden','play_button_absent','selecting_episode_number','pressing_episode_header','pressing_episode_play','checking_playback_after_unconfirmed','rechecking_episode_list',
  'opening_season_menu','selecting_next_season','selecting_previous_season','next_season_first_episode_found','previous_season_last_episode_found']);
function executionDetail(steps) {
  if (steps.includes('preview_play_button_missing')) return '이전/다음 회차 항목을 선택했지만, 펼쳐진 미리보기의 재생 버튼을 찾지 못했습니다.';
  if (steps.includes('navigation_unconfirmed')) return '재생 버튼까지 클릭했지만, 제한 시간 안에 재생 주소가 바뀌지 않았습니다.';
  if (steps.includes('current_episode_unclear')) return '회차 목록은 찾았지만 현재 재생 중인 회차를 특정하지 못했습니다.';
  if (steps.includes('navigation_confirmed')) return '재생 주소 변경을 확인했습니다.';
  return steps.length ? '실행 기록이 남았습니다. 마지막 실행 기록 복사로 공유할 수 있습니다.' : '실행 단계가 없습니다. NUV 연결과 제어할 영상 탭을 확인한 뒤 키를 눌러주세요.';
}
async function diagnoseNetflix() {
  if (!DIAGNOSTICS || diagnosticRunning) return;
  diagnosticRunning = true;
  try {
    await chrome.storage.session.set({ diagnostic: { status: '3초 뒤 확인합니다. 넷플릭스 영상으로 돌아가 회차 목록을 펼쳐주세요.', text: '' } });
    const { selected = {} } = await chrome.storage.session.get('selected');
    const target = selectTab(await chrome.tabs.query({ url: sites.Netflix }), 'Netflix', selected.Netflix);
    if (!target.tab) throw new Error(target.code === 'ambiguous' ? '넷플릭스 탭이 여러 개입니다. 아래에서 진단할 Netflix 탭을 선택해주세요.' : '넷플릭스 영상 탭을 먼저 열어주세요.');
    await new Promise(resolve => setTimeout(resolve, 3000));
    let response;
    try { const controller = await ensureTabController(target.tab);
      response = await chrome.tabs.sendMessage(target.tab.id, { type: 'netflix-diagnostic' }, controller.target); }
    catch { throw new Error('진단 연결을 복구하지 못했습니다. 테스트 확장의 사이트 접근 허용과 선택한 영상 탭을 확인해주세요.'); }
    if (response?.report?.schema !== 'nuv-netflix-structure-v1') throw new Error('진단 코드의 응답을 받지 못했습니다. 최신 테스트 확장과 선택한 영상 탭을 확인해주세요.');
    const text = JSON.stringify({ extensionVersion: chrome.runtime.getManifest().version, ...response.report }, null, 2);
    if (text.length > 120000) throw new Error('진단 결과가 너무 큽니다. 회차 목록을 닫고 다시 시도해주세요.');
    await chrome.storage.session.set({ diagnostic: { status: response.report.watchPage && response.report.videoCount === 1
      ? '진단 완료. 아래 결과를 확인한 뒤 복사해서 보내주세요.' : '시리즈 재생 화면을 찾지 못했습니다. 영상을 재생한 뒤 다시 진단해주세요.', text } });
  } catch (error) {
    // Only our own fixed error messages are displayed; never copy browser exception details into the report.
    await chrome.storage.session.set({ diagnostic: { status: error?.message || '진단하지 못했습니다.', text: '' } });
  } finally { diagnosticRunning = false; }
}
function cancelEpisodes() {
  for (const [id, state] of pendingEpisodes) {
    chrome.tabs.sendMessage(state.tabId, { type: 'nuv-cancel-v2', id }, { frameId: 0 }).catch(() => {});
  }
  pendingEpisodes.clear();
}
function resultText(code) {
  return ({ ok: '영상 버튼에 실행을 요청했습니다. 실제 재생 이동은 영상에서 확인해주세요.',
    video_moved: '치지직 영상 주소가 변경되었습니다.',
    video_unconfirmed: '영상 이동을 요청했지만 변경을 확인하지 못했습니다. 재생 화면을 확인해주세요.',
    skip_unconfirmed: '광고 SKIP 버튼을 눌렀지만 광고 종료를 확인하지 못했습니다.',
    not_ready: '지금은 사용할 영상 버튼이 준비되지 않았습니다.',
    debugger_busy: '영상 탭의 개발자 도구나 다른 디버깅 연결을 닫고 다시 눌러주세요.',
    episode_moved: 'Netflix 재생 주소가 다른 회차로 변경되었습니다.',
    episode_boundary: '현재 시즌의 회차 목록에 이전 또는 다음 화가 없습니다. 시즌 경계는 넷플릭스에서 선택해주세요.',
    episode_unavailable: '회차를 확인하지 못했습니다. Netflix 시리즈 영상에서 회차 목록을 열고 다시 눌러주세요.',
    episode_unconfirmed: '회차 이동 결과를 아직 확인하지 못했습니다. 재생 상태가 안정된 뒤 키를 다시 누르면 현재 회차를 확인하고 실행합니다.',
    episode_busy: '회차 이동 또는 재생 상태를 확인 중입니다. 잠시 후 키를 다시 눌러주세요.',
    no_tab: '영상 탭을 찾지 못했습니다. 해당 서비스의 영상을 열어주세요.',
    ambiguous: '영상 탭이 여러 개입니다. 아래에서 제어할 탭을 선택해주세요.',
    no_player: '선택된 탭에서 영상 플레이어를 찾지 못했습니다.',
    not_available: '현재 사용할 수 있는 건너뛰기 또는 이전·다음 버튼을 찾지 못했습니다.',
    no_receiver: '영상 탭의 제어 연결을 복구하지 못했습니다. 확장의 사이트 접근 허용과 영상 탭 상태를 확인한 뒤 다시 눌러주세요.',
    disabled: '연결이 해제되어 실행하지 않았습니다.',
    expired: '명령이 지연되어 실행하지 않았습니다. 다시 눌러주세요.',
    unsupported_action: '이 확장이 지원하지 않는 동작입니다. 최신 NUV 확장으로 업데이트해주세요.',
    page_changed: '회차 목록 확인 중 영상이 바뀌어 실행을 취소했습니다.',
    duplicate: '중복 명령이어서 다시 실행하지 않았습니다.' })[code] || '영상 제어에 실패했습니다. 영상 탭을 새로고침하고 다시 눌러주세요.';
}
const seen = new Set();
function connect() {
  if (port) return Promise.resolve();
  if (connectionTask) return connectionTask;
  const epoch = generation;
  connectionTask = (async () => {
    const settings = await chrome.storage.local.get(['connect', 'channel']);
    if (!settings.connect || epoch !== generation) return;
    // A legacy shared extension may have opted in to the other app. Require a fresh explicit choice.
    if (settings.channel && settings.channel !== RELEASE_CHANNEL) {
      await chrome.storage.local.set({connect:false, channel:RELEASE_CHANNEL, extensionUpdateExpected:'', extensionUpdateStatus:''});
      status = '정식·테스트 확장이 분리되었습니다. 사용할 NUV에서 다시 연결해주세요.';
      return;
    }
    await chrome.alarms.create('reconnect', { periodInMinutes: 1 });
    if (epoch !== generation) return;
    const current = chrome.runtime.connectNative(RELEASE_CHANNEL === 'beta' ? 'com.nuv.browser.beta' : 'com.nuv.browser');
    port = current;
    autoSkip = {}; autoSkipStateAt = 0;
    enabled = false;
    status = 'NUV 연결 확인 중';
    current.onMessage.addListener(message => handleNative(current, message));
    current.onDisconnect.addListener(() => {
      const reason = chrome.runtime.lastError?.message;
      if (port !== current) return;
      port = null; enabled = false; autoSkip = {}; autoSkipStateAt = 0; generation++; cancelEpisodes(); cancelUpdateRequest();
      clearInterval(heartbeat); heartbeat = null;
      status = reason ? 'NUV를 실행하고 앱의 설치 안내를 완료한 뒤 다시 연결해주세요.' : '연결 끊김 · 다시 연결 대기';
    });
    current.postMessage({ type: 'hello', version: 1, extensionVersion: chrome.runtime.getManifest().version, capabilities: ['netflixEpisodes','favoriteTabs','unifiedFavorites','autoSkipV1','youtubeAdSkipV1','chzzkControlV1','netflixAutoNextV1'], browser: /Edg\//.test(globalThis.navigator?.userAgent || '') ? 'edge' : 'chrome' });
    heartbeat = setInterval(() => { if (port === current) current.postMessage({ type: 'ping' }); }, 15000);
  })().finally(() => { connectionTask = null; });
  return connectionTask;
}
function disconnect() {
  cancelUpdateRequest();
  generation++; enabled = false; autoSkip = {}; autoSkipStateAt = 0; cancelEpisodes();
  const current = port; port = null;
  if (current) current.disconnect();
  clearInterval(heartbeat); heartbeat = null;
  chrome.alarms.clear('reconnect');
  status = '연결 안 됨';
}
async function handleNative(current, message) {
  if (port !== current) return;
  if (message?.type === 'state') {
    const previousPreferences = JSON.stringify(autoSkip);
    if (message.channel && message.channel !== RELEASE_CHANNEL) { disconnect(); status = '다른 채널의 NUV에는 연결할 수 없습니다.'; return; }
    updaterProtocol = message.extensionUpdater === 1 ? 1 : 0;
    nativeChannel = message.channel === 'beta' ? 'beta' : message.channel === 'stable' ? 'stable' : null;
    if (enabled !== (message.enabled === true)) generation++;
    enabled = message.enabled === true;
    // Older PCs send partial state packets for favorites/workspaces. Absence
    // is not an opt-out and must not refresh the settings' expiry timestamp.
    if (!enabled) { autoSkip = {}; autoSkipStateAt = 0; }
    else if (Object.prototype.hasOwnProperty.call(message, 'autoSkip')) {
      autoSkip = normalizedAutoSkip(message.autoSkip);
      autoSkipStateAt = Date.now();
    }
    if (enabled && Object.values(autoSkip).some(Boolean)) void prepareAutoSkipTabs(previousPreferences !== JSON.stringify(autoSkip));
    void youtubeBackgroundControl.sync().catch(() => {});
    void chzzkBackgroundControl.sync().catch(() => {});
    if (!enabled) cancelEpisodes();
    favoriteScope = /^(local|[A-Fa-f0-9]{64})$/.test(message.favoriteScope || '') ? message.favoriteScope : null;
    status = enabled ? '연결됨' : 'NUV 앱에서 연결을 켜주세요';
    return;
  }
  if (message?.type === 'extension-update-result') {
    const pending = updatePending;
    if (!pending || pending.current !== current || pending.id !== message.id) return;
    clearTimeout(pending.timer); updatePending = null;
    const codes = new Set(['updated','current','busy','setup_required','error']);
    pending.resolve(codes.has(message.code) && typeof message.message === 'string' && message.message.length <= 500 &&
      (message.code !== 'updated' || /^\d+\.\d+\.\d+(?:\.\d+)?$/.test(message.version))
      ? { code: message.code, message: message.message, version: message.version } : { code: 'error', message: 'NUV 업데이트 응답을 확인할 수 없습니다.' });
    return;
  }
  if (message?.type === 'favorite-control') {
    const epoch=generation;
    const live=()=>port===current&&enabled&&generation===epoch&&favoriteScope===message.scope&&Date.now()<message.expiresAt;
    let result={code:'expired',profile:'',entries:[]};
    if (!enabled) result.code='disabled';
    else if (updateTask) result.code='favorite_busy';
    else if (!['snapshot','toggle','activate','remove','workspace-check','workspace-prepare','workspace-save','workspace-restore','workspace-capture','workspace-list'].includes(message.action) || !/^[0-9a-f]{32}$/.test(message.id)) result.code='unsupported_action';
    else if (Number.isSafeInteger(message.expiresAt)&&message.expiresAt<=Date.now()+(message.action?.startsWith('workspace-')?21000:5000)&&live()) {
      if(seen.has(message.id)) result.code='duplicate';
      else {seen.add(message.id);if(seen.size>128)seen.delete(seen.values().next().value);
        try {result=await favorites().unified(message.scope,message.action,message.reference,live);}catch{result.code='favorite_failed';}}
    }
    // NUV owns unified favorites feedback; the extension popup remains a connection/video UI.
    if(port===current)current.postMessage({type:'favorite-control-result',id:message.id,...result});
    return;
  }
  if (message?.type === 'favorite-tab') {
    let code = 'error'; const epoch = generation;
    const live = () => port === current && enabled && generation === epoch && favoriteScope === message.scope && Date.now() < message.expiresAt;
    if (!enabled) code = 'disabled';
    else if (updateTask) code = 'favorite_busy';
    else if (!['ToggleFavoriteTab','NextFavoriteTab'].includes(message.action) || !/^[0-9a-f]{32}$/.test(message.id)) code = 'unsupported_action';
    else if (!Number.isSafeInteger(message.expiresAt) || message.expiresAt > Date.now()+5000 || !live()) code = 'expired';
    else if (seen.has(message.id)) code = 'duplicate';
    else { seen.add(message.id); if(seen.size>128)seen.delete(seen.values().next().value); code = await favorites().run(message.scope,message.action,null,live); }
    lastResult = favoriteText(code);
    if (port === current) current.postMessage({type:'result',id:message.id,code});
    return;
  }
  if (message?.type !== 'execute') return;
  lastResult = 'NUV 명령을 받았습니다. 영상 탭 확인 중…';
  let code = 'error';
  let episodeSteps = [];
  const epoch = generation;
  try {
    if (updateTask) code = 'episode_busy';
    else if (!enabled) code = 'disabled';
    else if (!Object.hasOwn(actions, message.action)) code = 'unsupported_action';
    else if (actions[message.action] !== message.service || !/^[0-9a-f]{32}$/.test(message.id)) code = 'error';
    else if (!validCommand(message)) code = 'expired';
    else if (seen.has(message.id)) code = 'duplicate';
    else {
      seen.add(message.id);
      if (seen.size > 128) seen.delete(seen.values().next().value);
      const tabs = await chrome.tabs.query({ url: sites[message.service] });
      const { selected = {} } = await chrome.storage.session.get('selected');
      const target = selectTab(tabs, message.service, selected[message.service]);
      if (!enabled || generation !== epoch || current !== port) code = 'disabled';
      else if (!validCommand(message)) code = 'expired';
      else if (!target.tab) code = target.code;
      else {
        // Does not activate the tab/window or generate keyboard input.
        try {
          const episode = message.action === 'BrowserNetflixPreviousEpisode' || message.action === 'BrowserNetflixNextEpisode';
          const controller = await ensureTabController(target.tab);
          const probe = controller.probe;
          if (episode && probe?.netflixEpisodes !== true) code = 'no_receiver';
          else if (!enabled || generation !== epoch || current !== port) code = 'disabled';
          else if (!validCommand(message)) code = 'expired';
          else {
            if (episode || message.action === 'BrowserNetflixSkipIntro' || message.action === 'BrowserDisneySkipIntro')
              pendingEpisodes.set(message.id, { tabId: target.tab.id, url: target.tab.url, expiresAt: message.expiresAt });
            if (message.service === '치지직') chzzkCommands.set(message.id, {...message, tabId:target.tab.id, url:target.tab.url, epoch, current});
            const result = await withNetflixControls(message,target.tab,controller.target,
              ()=>enabled&&port===current&&generation===epoch&&Date.now()<message.expiresAt,
              ()=>chrome.tabs.sendMessage(target.tab.id, { ...message, type: 'nuv-execute-v2', expectedUrl: target.tab.url }, controller.target));
            code = typeof result?.code === 'string' ? result.code : 'error';
            if (DIAGNOSTICS && episode && Array.isArray(result?.episodeSteps)) episodeSteps = result.episodeSteps.filter(step => episodeStages.has(step)).slice(0, 24);
          }
        } catch (error) {
          code = error?.message === 'page_changed' ? 'page_changed' : 'no_receiver';
        } finally {
          if (message.service === '치지직' && ['BrowserChzzkPrevious','BrowserChzzkNext'].includes(message.action) && chzzkCommands.has(message.id) && ['clicked','ok','video_unconfirmed','no_receiver'].includes(code)) {
            const until = Math.min(message.expiresAt, Date.now()+1300);
            while(Date.now()<until && enabled && port===current && generation===epoch) {
              const live = await chrome.tabs.get(target.tab.id).catch(()=>null);
              if (live?.url !== target.tab.url && /^https:\/\/chzzk\.naver\.com\/video\/\d+/.test(live?.url||'')) {code='video_moved';break;}
              await new Promise(resolve=>setTimeout(resolve,80));
            }
            if(code==='clicked'||code==='ok') code='video_unconfirmed';
          }
          chzzkCommands.delete(message.id); pendingEpisodes.delete(message.id);
        }
      }
    }
  } catch { code = 'error'; }
  lastResult = resultText(code);
  if (DIAGNOSTICS && (message.action === 'BrowserNetflixPreviousEpisode' || message.action === 'BrowserNetflixNextEpisode')) {
    const safeCodes = new Set(['error','episode_moved','episode_boundary','episode_unavailable','episode_unconfirmed','episode_busy',
      'no_receiver','no_player','no_tab','ambiguous','disabled','expired','page_changed','duplicate']);
    const report = { schema: 'nuv-netflix-execution-v1', extensionVersion: chrome.runtime.getManifest().version,
      action: message.action === 'BrowserNetflixPreviousEpisode' ? 'previous' : 'next', code: safeCodes.has(code) ? code : 'error', steps: episodeSteps };
    await chrome.storage.session.set({ execution: { detail: executionDetail(episodeSteps), text: JSON.stringify(report, null, 2) } }).catch(() => {});
  }
  if (port === current) current.postMessage({ type: 'result', id: message.id, code });
}
async function authorizeChzzk(message, sender) {
  if (!message.requestId) return message.action ? {allowed:false} : authorizeAutoSkip(message,sender);
  const command=chzzkCommands.get(message.requestId);
  if (!command || command.tabId!==sender.tab?.id || command.action!==message.action || command.url!==message.expectedUrl ||
      !enabled || updateTask || reloading || command.current!==port || command.epoch!==generation || Date.now()>=command.expiresAt) return {allowed:false};
  const {selected={}}=await chrome.storage.session.get('selected');
  const target=selectTab(await chrome.tabs.query({url:sites['치지직']}),'치지직',selected['치지직']);
  return {allowed:target.tab?.id===command.tabId && target.tab.url===command.url};
}
const chzzkBackgroundControl = createYouTubeBackgroundControl(chrome, authorizeChzzk, () => !!port && enabled && !updateTask && !reloading, '치지직');
const youtubeBackgroundControl = createYouTubeBackgroundControl(chrome, authorizeAutoSkip, () => autoSkipAllowed('YouTube','ad'));
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (message?.type?.startsWith('nuv-youtube-background-') || message?.type?.startsWith('nuv-chzzk-')) return false;
  if (message?.type === 'nuv-auto-skip-check') {
    authorizeAutoSkip(message, sender).then(respond, () => respond({ allowed: false }));
    return true;
  }
  // Settings are only accepted from our popup, never a content script/web page.
  if (sender.id !== chrome.runtime.id || sender.url !== chrome.runtime.getURL('popup.html')) return false;
  (async () => {
    if (message.type === 'update-extension') await updateExtension();
    if (DIAGNOSTICS && message.type === 'diagnose-netflix') {
      // Popup click only; no native-host command or automatic diagnosis path.
      await diagnoseNetflix();
    }
    if (message.type === 'connect') {
      const previous = await chrome.storage.local.get(['channel']);
      if (previous.channel && previous.channel !== (RELEASE_CHANNEL))
        await chrome.storage.local.set({ extensionUpdateExpected: '', extensionUpdateStatus: '' });
      await chrome.storage.local.set({ connect: true, channel: RELEASE_CHANNEL });
      disconnect();
      if (connectionTask) await connectionTask;
      await connect();
    } else if (message.type === 'disconnect') {
      await chrome.storage.local.set({ connect: false }); disconnect();
    } else if (message.type === 'select' && Object.hasOwn(sites, message.service)) {
      const { selected = {} } = await chrome.storage.session.get('selected');
      const tabs = await chrome.tabs.query({ url: sites[message.service] });
      if (message.tabId === null) delete selected[message.service];
      else if (tabs.some(t => t.id === message.tabId && serviceOf(t.url) === message.service)) selected[message.service] = message.tabId;
      await chrome.storage.session.set({ selected });
    }
    const tabs = await chrome.tabs.query({ url: Object.values(sites) });
    const { selected = {} } = await chrome.storage.session.get('selected');
    const settings = await chrome.storage.local.get(['connect', 'channel', 'extensionUpdateStatus','extensionUpdateExpected']);
    if (!reloading && settings.extensionUpdateExpected) {
      if (versionAtLeast(chrome.runtime.getManifest().version, settings.extensionUpdateExpected))
        await chrome.storage.local.set({ extensionUpdateExpected: '' });
      else settings.extensionUpdateStatus = '다시 로드한 확장의 버전이 바뀌지 않았습니다. PC NUV 설치 안내의 폴더로 다시 등록해주세요.';
    }
    const { diagnostic = null, execution = null } = DIAGNOSTICS ? await chrome.storage.session.get(['diagnostic','execution']) : {};
    settings.channel = RELEASE_CHANNEL;
    respond({ status, lastResult, diagnostic, execution, enabled, connected: !!port, settings, selected,
      updateRunning: !!updateTask || reloading, extensionVersion: chrome.runtime.getManifest().version_name || chrome.runtime.getManifest().version,
      tabs: tabs.map(t => ({ id: t.id, title: t.title || serviceOf(t.url), service: serviceOf(t.url) })) });
  })().catch(() => respond({ status: '연결 상태를 확인하지 못했습니다.', tabs: [], selected: {}, settings: {} }));
  return true;
});
chrome.runtime.onStartup.addListener(() => { favorites().clear().finally(connect); });
// Register close listeners synchronously when the service worker starts.
if (chrome.tabs.onRemoved && chrome.tabs.onReplaced) favorites();
chrome.runtime.onInstalled.addListener(connect);
chrome.alarms.onAlarm.addListener(alarm => { if (alarm.name === 'reconnect') connect(); });
connect();
