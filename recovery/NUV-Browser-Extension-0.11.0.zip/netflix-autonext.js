// Only Netflix's end-of-episode card. Never the always-available control-next,
// recommendations, trailers, purchases, guessed episode URLs or keyboard input.
(() => {
  if(location.origin!=='https://www.netflix.com')return;
  const version=chrome.runtime.getManifest().version,previous=globalThis.NuvNetflixAutoNext;
  if(previous?.version===version&&previous.active)return;
  previous?.dispose();
  let state=previous?.state||{url:'',attempt:null},disposed=false,busy=false,again=false,notBefore=0,frame=null;
  const selector='[data-uia="next-episode-seamless-button"], [data-uia="next-episode-seamless-button-draining"]';
  function visible(element) {
    if(!element?.isConnected||!element.getClientRects().length||element.disabled||element.getAttribute('aria-disabled')==='true')return false;
    const own=getComputedStyle(element);
    if(['hidden','collapse'].includes(own.visibility)||own.pointerEvents==='none')return false;
    for(let node=element;node;node=node.parentElement){const style=getComputedStyle(node);if(style.display==='none'||style.opacity==='0')return false;}
    return true;
  }
  function candidate() {
    if(!/^\/watch\/\d+\/?$/.test(location.pathname))return null;
    const surface=document.querySelector('.watch-video');if(!surface)return null;
    const videos=[...surface.querySelectorAll('video')].filter(v=>v.isConnected&&v.getClientRects().length&&getComputedStyle(v).display!=='none');
    if(videos.length!==1||videos[0].seeking||videos[0].readyState<2)return null;
    const buttons=[...new Set([...surface.querySelectorAll(selector)].flatMap(marker=>{
      if(marker.matches('button, a[href], [role="button"]'))return [marker];
      return [...marker.querySelectorAll('button, a[href], [role="button"]')];
    }))].filter(visible);
    return buttons.length===1?{button:buttons[0],video:videos[0],url:location.href,source:videos[0].currentSrc}:null;
  }
  async function check(followup=false) {
    if(disposed)return;if(busy){again=true;return;}
    if(state.url!==location.href)state={url:location.href,attempt:null};
    if(state.attempt||Date.now()<notBefore||globalThis.NuvPlayerController?.navigationPending?.())return;
    const found=candidate();if(!found)return;
    busy=true;again=false;
    try {
      const permit=await chrome.runtime.sendMessage({type:'nuv-auto-skip-check',kind:'nextEpisode',expectedUrl:found.url});
      if(disposed)return;
      if(!permit?.allowed){notBefore=Date.now()+500;return;}
      const current=candidate();
      if(state.attempt||globalThis.NuvPlayerController?.navigationPending?.()||!current||current.url!==found.url||current.video!==found.video||current.source!==found.source||
        permit.kind!=='nextEpisode'||permit.expectedUrl!==found.url||!Number.isSafeInteger(permit.expiresAt)||permit.expiresAt<=Date.now()||permit.expiresAt>Date.now()+1500)return;
      // Claim once BEFORE dispatch. A still-visible card or late navigation is
      // not grounds to press Next again. Manual recovery verifies the episode list.
      state.attempt={url:found.url,at:Date.now()};
      globalThis.NuvNetflixEpisodes?.markNavigationAttempt?.(state.attempt.at);
      current.button.click();
    } catch {notBefore=Date.now()+500;}
    finally {busy=false;if(again&&!followup&&!disposed){again=false;void check(true);}}
  }
  const wake=()=>{void check();};
  const animated=()=>{
    wake();if(frame!==null||typeof requestAnimationFrame!=='function')return;
    let remaining=3;const tick=()=>{frame=null;wake();if(!disposed&&--remaining>0)frame=requestAnimationFrame(tick);};frame=requestAnimationFrame(tick);
  };
  const listener=(message,sender,reply)=>{if(disposed||sender.id!==chrome.runtime.id||message?.type!=='nuv-netflix-autonext-wake')return false;notBefore=0;wake();reply({ok:true});return false;};
  const observer=new MutationObserver(wake);observer.observe(document.documentElement,{childList:true,subtree:true,attributes:true,attributeFilter:['class','style','disabled','aria-disabled','data-uia']});
  const timer=setInterval(wake,500);
  const events=['timeupdate','ended','playing','loadeddata','visibilitychange'];for(const e of events)document.addEventListener(e,wake,true);
  for(const e of ['transitionstart','animationstart','transitionend','animationend'])document.addEventListener(e,animated,true);
  chrome.runtime.onMessage.addListener(listener);
  globalThis.NuvNetflixAutoNext={version,active:true,check,get state(){return state;},get pendingAttempt(){return state.url===location.href?state.attempt:null;},dispose(){this.active=false;disposed=true;observer.disconnect();clearInterval(timer);if(frame!==null)cancelAnimationFrame(frame);chrome.runtime.onMessage.removeListener(listener);for(const e of events)document.removeEventListener(e,wake,true);for(const e of ['transitionstart','animationstart','transitionend','animationend'])document.removeEventListener(e,animated,true);}};
  wake();
})();
