(() => {
const state = document.getElementById('status');
if (location.protocol !== 'chrome-extension:' || !globalThis.chrome?.runtime?.id ||
    typeof chrome.runtime.sendMessage !== 'function') {
  state.textContent = '아직 확장으로 실행되지 않았습니다 · 아래 설치 안내를 따라주세요';
  return;
}
document.getElementById('install-guide').hidden = true;
document.getElementById('connection-controls').hidden = false;
const showError = () => { state.textContent = '확장 응답을 받지 못했습니다. 확장 관리 화면에서 NUV를 새로고침하고 다시 열어주세요.'; };
function showUpdate(result) {
  document.getElementById('extension-version').textContent = `현재 버전: ${result.extensionVersion || chrome.runtime.getManifest?.().version || '확인 중'}`;
  document.getElementById('update-extension').disabled = result.updateRunning === true;
  document.getElementById('update-status').textContent = result.settings?.extensionUpdateStatus || '버튼을 누르면 연결된 PC NUV가 같은 채널의 새 버전을 확인하고 설치합니다.';
}
function showExecution(value) {
  if (!value || !document.getElementById('execution-detail')) return;
  document.getElementById('execution-detail').textContent = value.detail;
  document.getElementById('execution-report').value = value.text || '';
  document.getElementById('copy-execution').disabled = !value.text;
}
function showDiagnostic(value) {
  if (!value || !document.getElementById('diagnostic-status')) return;
  document.getElementById('diagnostic-status').textContent = value.status;
  const field = document.getElementById('diagnostic-report');
  field.value = value.text || ''; field.hidden = !field.value;
  document.getElementById('copy-diagnostic').disabled = !field.value;
}
async function render(message = { type: 'status' }) {
  try {
  const result = await chrome.runtime.sendMessage(message);
  showUpdate(result);
  document.getElementById('status').textContent = result.status;
  showDiagnostic(result.diagnostic);
  showExecution(result.execution);
  document.getElementById('result').textContent = result.lastResult || '아직 NUV에서 받은 실행 명령이 없습니다.';
  document.getElementById('channel').value = result.settings.channel || 'stable';
  const root = document.getElementById('tabs'); root.replaceChildren();
  for (const service of ['YouTube', 'Netflix', 'Disney+']) {
    const label = document.createElement('label'); label.textContent = service;
    const select = document.createElement('select'); select.setAttribute('aria-label', `${service} 제어할 탭`);
    const automatic = document.createElement('option'); automatic.value = ''; automatic.textContent = '자동 선택 (탭 한 개일 때)'; select.append(automatic);
    for (const tab of result.tabs.filter(t => t.service === service)) {
      const option = document.createElement('option'); option.value = String(tab.id); option.textContent = tab.title; select.append(option);
    }
    if (result.selected[service] != null) {
      if (!result.tabs.some(t => t.id === result.selected[service] && t.service === service)) {
        const stale = document.createElement('option'); stale.value = String(result.selected[service]); stale.textContent = '선택했던 탭이 닫혔습니다 · 다시 선택'; select.append(stale);
      }
      select.value = String(result.selected[service]);
    }
    select.addEventListener('change', () => render({ type: 'select', service, tabId: select.value ? Number(select.value) : null }));
    root.append(label, select);
  }
  } catch {
    showError();
    if (message.type === 'update-extension') {
      document.getElementById('update-extension').disabled = false;
      document.getElementById('update-status').textContent = '업데이트 응답을 받지 못했습니다. 확장을 다시 열어 결과를 확인해주세요.';
    }
  }
}
document.getElementById('workspace-permission').onclick = async () => {
  const text = document.getElementById('workspace-permission-status');
  try { text.textContent = await chrome.permissions.request({permissions:['tabs']}) ? '허용됐습니다. PC NUV에서 작업 공간을 저장하세요.' : '허용하지 않았습니다. 앱 창은 권한 없이 저장할 수 있습니다.'; }
  catch { text.textContent = '권한을 요청하지 못했습니다. 확장을 업데이트하고 다시 열어주세요.'; }
};
document.getElementById('connect').onclick = () => render({ type: 'connect', channel: document.getElementById('channel').value });
document.getElementById('disconnect').onclick = () => render({ type: 'disconnect' });
document.getElementById('refresh').onclick = () => render();
document.getElementById('update-extension').onclick = async () => {
  document.getElementById('update-extension').disabled = true;
  document.getElementById('update-status').textContent = '업데이트 확인 중…';
  await render({ type: 'update-extension' });
};
if (document.getElementById('copy-execution')) document.getElementById('copy-execution').onclick = async () => {
  const field = document.getElementById('execution-report'); if (!field.value) return;
  try { await navigator.clipboard.writeText(field.value); document.getElementById('execution-detail').textContent = '실행 기록을 복사했습니다. 채팅에 붙여넣어 주세요.'; }
  catch { field.hidden = false; field.focus(); field.select(); document.getElementById('execution-detail').textContent = '선택된 실행 기록을 Ctrl+C로 복사해주세요.'; }
};
if (document.getElementById('diagnose')) document.getElementById('diagnose').onclick = async () => {
  const button = document.getElementById('diagnose'); button.disabled = true;
  showDiagnostic({status:'3초 뒤 확인합니다. 영상으로 돌아가 회차 목록을 펼쳐주세요.',text:''});
  try { await render({type:'diagnose-netflix'}); } finally { button.disabled = false; }
};
if (document.getElementById('copy-diagnostic')) document.getElementById('copy-diagnostic').onclick = async () => {
  const field = document.getElementById('diagnostic-report'); if (!field.value) return;
  try { await navigator.clipboard.writeText(field.value); document.getElementById('diagnostic-status').textContent = '복사했습니다. 채팅에 붙여넣어 주세요. 자동으로 전송되지는 않습니다.'; }
  catch { field.focus(); field.select(); document.getElementById('diagnostic-status').textContent = '복사가 허용되지 않았습니다. 선택된 결과를 Ctrl+C로 복사해주세요.'; }
};
render();
setInterval(() => chrome.runtime.sendMessage({ type: 'status' }).then(r => {
  state.textContent = r.status;
  showUpdate(r);
  showDiagnostic(r.diagnostic);
  showExecution(r.execution);
  document.getElementById('result').textContent = r.lastResult || '아직 NUV에서 받은 실행 명령이 없습니다.';
}).catch(showError), 1500);
})();
