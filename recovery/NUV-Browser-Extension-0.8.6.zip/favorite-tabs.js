// URLs remain in the browser. Unified control shares only favorite IDs and short titles with local NUV.
export function createTabFavorites(api) {
  const prefix = 'favoriteTabsV1_', workspacePrefix = 'workspaceTabsV1_';
  let queue = Promise.resolve(), executing = false;
  const enqueue = fn => { const task = queue.then(fn); queue = task.catch(() => {}); return task; };
  const validScope = s => typeof s === 'string' && /^(local|[A-Fa-f0-9]{64})$/.test(s);
  const allowed = t => Number.isInteger(t?.id) && !t.incognito;
  // Tab activation and IDs require no tabs permission. Titles may be unavailable.
  const load = async scope => {
    const key = prefix + scope, value = (await api.storage.local.get(key))[key];
    return { key, entries: Array.isArray(value?.entries) ? value.entries : [], last: value?.last || null };
  };
  const save = data => api.storage.local.set({ [data.key]: { entries: data.entries, last: data.last } });
  const savedTabs = async scope => {
    const key=workspacePrefix+scope, value=(await api.storage.local.get(key))[key];
    return {key,entries:Array.isArray(value?.entries)?value.entries:[]};
  };
  const saveTabs = d => api.storage.local.set({[d.key]:{entries:d.entries}});
  const safeUrl = value => { try { const u=new URL(value); return ['http:','https:'].includes(u.protocol)&&!u.username&&!u.password&&value.length<=8192; } catch { return false; } };
  const readIds = value => { try { const ids=JSON.parse(value); return Array.isArray(ids)&&ids.length>0&&ids.length<=100&&new Set(ids).size===ids.length&&ids.every(id=>typeof id==='string'&&id.length<=64)?ids:null; } catch {return null;} };
  const candidates = async scope => (await api.storage.session.get('workspaceCandidates_'+scope))['workspaceCandidates_'+scope] || [];
  async function listWorkspace(scope, reference, live) {
    if(executing)return {code:'favorite_busy',entries:[]};executing=true;
    try{return await enqueue(async()=>{
      if(!await api.permissions?.contains({permissions:['tabs']}))return {code:'workspace_permission',entries:[]};
      let groupId, references=[];
      try {const selection=JSON.parse(reference||'{}');groupId=selection.groupId;references=Array.isArray(selection.references)?selection.references.slice(0,100):[];}catch{}
      const previous=await candidates(scope), saved=await savedTabs(scope), entries=[];
      for(const tab of (await api.tabs.query({})).filter(allowed)) {
        if(!safeUrl(tab.url))continue;
        const w=await api.windows.get(tab.windowId);if(w.type!=='normal'||w.incognito)continue;
        const id=saved.entries.find(e=>references.includes(e.id)&&e.tabId===tab.id)?.id
          || saved.entries.find(e=>groupId&&e.groupId===groupId&&e.tabId===tab.id)?.id
          || previous.find(e=>e.tabId===tab.id)?.id || crypto.randomUUID();
        entries.push({id,tabId:tab.id,title:(tab.title||'웹 탭').slice(0,32)});
        if(entries.length>=200)break;
      }
      if(!live())return {code:'expired',entries:[]};
      // Listing stores identifiers only in browser-session memory. URLs are captured only on Save.
      await api.storage.session.set({['workspaceCandidates_'+scope]:entries});
      return {code:'ok',entries};
    });}catch{return {code:'favorite_failed',entries:[]};}finally{executing=false;}
  }
  async function captureWorkspace(scope, groupId, live) {
    if(executing)return {code:'favorite_busy'};executing=true;
    try{return await enqueue(async()=>{
      if(!/^[0-9a-f]{32}$/.test(groupId||''))return {code:'unsupported_action'};
      if(!await api.permissions?.contains({permissions:['tabs']}))return {code:'workspace_permission'};
      const tab=(await api.tabs.query({active:true,lastFocusedWindow:true}))[0];
      if(!allowed(tab))return {code:'favorite_no_tab'};
      if(!safeUrl(tab.url))return {code:'workspace_url'};
      const w=await api.windows.get(tab.windowId);if(w.type!=='normal'||w.incognito)return {code:'workspace_unsupported'};
      const data=await savedTabs(scope);
      let entry=data.entries.find(e=>e.groupId===groupId&&e.tabId===tab.id);
      if(!entry) {if(data.entries.length>=5000)return {code:'favorite_limit'};entry={id:crypto.randomUUID(),groupId};data.entries.push(entry);}
      Object.assign(entry,{tabId:tab.id,url:tab.url,title:(tab.title||'').slice(0,32)});
      if(!live())return {code:'expired'};
      await saveTabs(data);return {code:'workspace_ready',entry};
    });}catch{return {code:'favorite_failed'};}finally{executing=false;}
  }
  async function persistWorkspace(scope, reference, restore, live) {
    if(executing)return 'favorite_busy'; executing=true;
    try {return await enqueue(async()=>{
      let mappings;
      try {mappings=JSON.parse(reference).map(v=>typeof v==='string'?{source:v,id:v}:v);}catch{return 'unsupported_action';}
      if(!Array.isArray(mappings)||!mappings.length||mappings.length>100||mappings.some(m=>!m||typeof m.source!=='string'||typeof m.id!=='string'||m.source.length>64||m.id.length>64)||new Set(mappings.map(m=>m.id)).size!==mappings.length)return 'unsupported_action';
      const ids=mappings.map(m=>m.id);
      if(!await api.permissions?.contains({permissions:['tabs']}))return 'workspace_permission';
      const data=await load(scope), durable=await savedTabs(scope), tabs=(await api.tabs.query({})).filter(allowed);
      if(!restore) {
        const capture=[];
        for(const {source,id} of mappings) {
          const binding=data.entries.find(e=>e.id===source) || durable.entries.find(e=>e.id===source) || (api.storage.session ? (await candidates(scope)).find(e=>e.id===source) : null);
          const tab=tabs.find(t=>t.id===binding?.tabId);
          // Resaving a closed entry keeps its original address.
          const prior=durable.entries.find(e=>e.id===source);
          if(!tab && prior && safeUrl(prior.url)) {capture.push({...prior,id});continue;}
          if(!tab)return 'favorite_empty';
          if(!safeUrl(tab.url))return 'workspace_url';
          const w=await api.windows.get(tab.windowId);if(w.type!=='normal'||w.incognito)return 'workspace_unsupported';
          capture.push({...prior,id,tabId:tab.id,url:tab.url,title:(tab.title||'').slice(0,32)});
        }
        if(!live())return 'expired';
        const next=durable.entries.filter(e=>!ids.includes(e.id)).concat(capture);
        if(next.length>5000)return 'favorite_limit';
        durable.entries=next;await saveTabs(durable);return 'workspace_ready';
      }
      const entries=ids.map(id=>durable.entries.find(e=>e.id===id));
      if(entries.some(e=>!e||!safeUrl(e.url)))return 'workspace_missing';
      // Reuse only our live binding. Never adopt an arbitrary tab with a matching title/URL.
      for(const e of entries) {
        if(!live())return 'expired';
        if(tabs.some(t=>t.id===e.tabId))continue;
        const tab=await api.tabs.create({url:e.url,active:false});
        e.tabId=tab.id;
        // Commit each opened binding immediately so retries never duplicate a successful open.
        await saveTabs(durable);
      }
      return live()?'workspace_ready':'expired';
    });}catch{return 'favorite_failed';}finally{executing=false;}
  }
  async function all(change) {
    const data = await api.storage.local.get(null);
    for (const key of Object.keys(data).filter(k => k.startsWith(prefix))) {
      const item = { key, entries: data[key]?.entries || [], last: data[key]?.last || null };
      change(item); await save(item);
    }
  }
  async function updateSaved(change) {
    const all=await api.storage.local.get(null);
    for(const key of Object.keys(all).filter(k=>k.startsWith(workspacePrefix))) {
      const d={key,entries:all[key]?.entries||[]};d.entries.forEach(change);await saveTabs(d);
    }
  }
  // IDs live only for this browser session. Extension reload keeps them; browser restart clears them.
  api.tabs.onRemoved.addListener(id => { void enqueue(async () => { await all(d => { d.entries = d.entries.filter(e => e.tabId !== id); }); await updateSaved(e=>{if(e.tabId===id)e.tabId=null;}); }); });
  api.tabs.onReplaced.addListener((added, removed) => { void enqueue(() => all(d => {
    for (const e of d.entries) if (e.tabId === removed) e.tabId = added;
  }).then(()=>updateSaved(e=>{if(e.tabId===removed)e.tabId=added;}))); });
  async function prune(data) {
    const tabs = (await api.tabs.query({})).filter(allowed);
    const liveIds = new Set(tabs.map(t => t.id));
    const before = data.entries.length;
    data.entries = data.entries.filter(e => liveIds.has(e.tabId));
    if (data.entries.length !== before) await save(data);
    return tabs;
  }
  async function run(scope, action, id, live = () => true) {
    if (!validScope(scope)) return 'favorite_scope';
    if (executing) return 'favorite_busy';
    executing = true;
    try { return await enqueue(async () => {
      const data = await load(scope); await prune(data);
      if (!live()) return 'expired';
      if (action === 'remove') {
        data.entries = data.entries.filter(e => e.id !== id); await save(data); return 'favorite_removed';
      }
      const active = (await api.tabs.query({ active: true, lastFocusedWindow: true }))[0];
      if (!live()) return 'expired';
      if (action !== 'SelectFavoriteTab' && (!allowed(active) || (await api.windows.get(active.windowId)).type !== 'normal')) return 'favorite_no_tab';
      if (action === 'ToggleFavoriteTab') {
        const existing = data.entries.find(e => e.tabId === active.id);
        if (existing) data.entries = data.entries.filter(e => e.id !== existing.id);
        else {
          if (data.entries.length >= 200) return 'favorite_limit';
          data.entries.push({ id: crypto.randomUUID(), tabId: active.id });
        }
        if (!live()) return 'expired';
        await save(data); return existing ? 'favorite_removed' : 'favorite_added';
      }
      if (!['NextFavoriteTab','SelectFavoriteTab'].includes(action)) return 'unsupported_action';
      let index = data.entries.findIndex(e => e.tabId === active?.id);
      if (index < 0) index = data.entries.findIndex(e => e.id === data.last);
      const entry = action === 'SelectFavoriteTab' ? (data.entries.find(e => e.id === id) || (await savedTabs(scope)).entries.find(e=>e.id===id)) : data.entries[(index + 1) % data.entries.length];
      if (!entry) return 'favorite_empty';
      const target = await api.tabs.get(entry.tabId);
      if (!allowed(target)) return 'favorite_no_tab';
      const window = await api.windows.get(target.windowId);
      if (window.type !== 'normal' || window.incognito) return 'favorite_no_tab';
      if (!live()) return 'expired';
      await api.tabs.update(target.id, { active: true });
      if (!live()) return 'expired';
      await api.windows.update(target.windowId, window.state === 'minimized' ? { state: 'normal', focused: true } : { focused: true });
      data.last = entry.id; await save(data); return 'favorite_selected';
    }); } catch { return 'favorite_failed'; }
    finally { executing = false; }
  }
  async function snapshot(scope) {
    if (!validScope(scope)) return { available: false, permitted: false, entries: [] };
    return await enqueue(async () => {
      const data = await load(scope), tabs = await prune(data);
      return { available: true, permitted: true, entries: data.entries.map(e => {
        const tab = tabs.find(t => t.id === e.tabId);
        return { id: e.id, title: tab?.title || '' };
      }) };
    });
  }
  async function prepareWorkspace(scope, reference, checkOnly, live) {
    if (executing) return 'favorite_busy';
    executing = true;
    try { return await enqueue(async () => {
      let ids; try { ids=JSON.parse(reference); } catch { return 'unsupported_action'; }
      if (!Array.isArray(ids) || ids.length===0 || ids.length>100 || new Set(ids).size!==ids.length || ids.some(id=>typeof id!=='string')) return 'unsupported_action';
      const data=await load(scope), allTabs=await prune(data), durable=await savedTabs(scope);
      const tabs=ids.map(id=>allTabs.find(t=>t.id===(durable.entries.find(e=>e.id===id)||data.entries.find(e=>e.id===id))?.tabId));
      if(tabs.some(t=>!t))return 'favorite_empty';
      const selected=new Set(tabs.map(t=>t.id)), sources=[...new Set(tabs.map(t=>t.windowId))];
      for(const id of sources) {
        const w=await api.windows.get(id);
        if(w.type!=='normal'||w.incognito)return 'workspace_unsupported';
      }
      const split=tabs.filter(t=>allTabs.some(other=>other.windowId===t.windowId&&!selected.has(other.id)));
      if(split.some(t=>t.pinned))return 'workspace_unsupported';
      if(!live())return 'expired';
      if(checkOnly||!split.length)return 'workspace_ready';
      const moved=[];
      try {
        // Preserve tab identity and page state; move existing tabs, never recreate URLs.
        const original=split.map(t=>({id:t.id,windowId:t.windowId,index:t.index??-1}));
        let destination;
        for(const tab of original) {
          if(!live())throw Error('expired');
          const current=await api.tabs.get(tab.id);
          if(current.windowId!==tab.windowId||current.pinned||current.incognito)throw Error('changed');
          if(destination===undefined) {
            const w=await api.windows.create({tabId:tab.id,focused:false}); destination=w.id;
          } else await api.tabs.move(tab.id,{windowId:destination,index:-1});
          moved.push(tab);
        }
        if(!live())throw Error('expired');
        // Check every target window contains only selected tabs, even if user moved tabs meanwhile.
        const now=await api.tabs.query({});
        const hosts=new Set(now.filter(t=>selected.has(t.id)).map(t=>t.windowId));
        if(now.filter(t=>selected.has(t.id)).length!==selected.size || now.some(t=>hosts.has(t.windowId)&&!selected.has(t.id)))throw Error('changed');
        return 'workspace_ready';
      } catch {
        for(const tab of moved.sort((a,b)=>a.index-b.index)) {
          try { await api.tabs.move(tab.id,{windowId:tab.windowId,index:tab.index}); } catch { /* Never close a live tab to roll back. */ }
        }
        return live()?'favorite_failed':'expired';
      }
    }); } catch { return 'favorite_failed'; }
    finally { executing=false; }
  }
  let profileTask;
  const profile = () => profileTask ||= (async () => {
    const key='favoriteProfileV1', old=(await api.storage.local.get(key))[key];
    if (typeof old === 'string' && /^[0-9a-f]{32}$/.test(old)) return old;
    const value=crypto.randomUUID().replaceAll('-',''); await api.storage.local.set({[key]:value}); return value;
  })();
  async function unified(scope, action, reference, live=()=>true) {
    const identity=await profile();
    const empty=code=>({profile:identity,code,entries:[],activeId:null,changedId:null});
    if(!validScope(scope)||!live())return empty('expired');
    const before=await load(scope), active=(await api.tabs.query({active:true,lastFocusedWindow:true}))[0];
    const previous=before.entries.find(e=>e.tabId===active?.id)?.id || null;
    let capture, listed;
    const code=action==='workspace-list' ? (listed=await listWorkspace(scope,reference,live)).code : action==='workspace-capture' ? (capture=await captureWorkspace(scope,reference,live)).code : ['workspace-save','workspace-restore'].includes(action) ? await persistWorkspace(scope,reference,action==='workspace-restore',live) : action.startsWith('workspace-') ? await prepareWorkspace(scope,reference,action==='workspace-check',live) : action==='snapshot' ? 'ok' : await run(scope,
      action==='toggle'?'ToggleFavoriteTab':action==='activate'?'SelectFavoriteTab':action==='remove'?'remove':'unsupported',reference,live);
    if(!live())return empty('expired');
    const view=await snapshot(scope), latest=await load(scope), current=(await api.tabs.query({active:true,lastFocusedWindow:true}))[0];
    const durable=await savedTabs(scope);
    const activeId=latest.entries.find(e=>e.tabId===current?.id)?.id || durable.entries.find(e=>e.tabId===current?.id)?.id || null;
    if(action.startsWith('workspace-')) {
      const ids=action==='workspace-capture'?[capture?.entry?.id]:readIds(reference)||[];
      view.entries=durable.entries.filter(e=>ids.includes(e.id)).map(e=>({id:e.id,title:e.title||''}));
    }
    if(action==='workspace-list')view.entries=listed?.entries || [];
    // Also fit the native relay's 64 KiB frame after JSON Unicode escaping (up to 200 entries).
    return {profile:identity,code,entries:view.entries.map(e=>({id:e.id,title:e.title.slice(0,32)})),activeId,
      changedId:action==='workspace-capture'?capture?.entry?.id||null:action==='remove'?reference:code==='favorite_removed'?previous:code==='favorite_added'?activeId:null};
  }
  return { run, snapshot, unified, clear: () => enqueue(async () => { await all(d => { d.entries = []; d.last = null; }); await updateSaved(e=>{e.tabId=null;}); }) };
}
