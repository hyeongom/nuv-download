(() => {
  const version = chrome.runtime.getManifest().version;
  const previous = globalThis.NuvPlayerController;
  if (previous?.version === version && previous.active) return;
  previous?.dispose();
  let disposed = false;
  const actions = {
    BrowserYouTubeMute: 'YouTube', BrowserYouTubeNext: 'YouTube', BrowserYouTubePrevious: 'YouTube',
    BrowserNetflixPreviousEpisode: 'Netflix', BrowserNetflixNextEpisode: 'Netflix',
    BrowserNetflixMute: 'Netflix', BrowserNetflixSkipIntro: 'Netflix', BrowserDisneyMute: 'Disney+', BrowserDisneySkipIntro: 'Disney+'
  };
  const service = { 'www.youtube.com': 'YouTube', 'www.netflix.com': 'Netflix', 'www.disneyplus.com': 'Disney+' }[location.hostname];
  const seen = previous?.seen || new Set();
  const pendingEpisodes = new Map();
  // Older controllers recorded attempts as success. Do not inherit those false positives.
  const autoHistory = previous?.autoStateVersion === 4 ? previous.autoHistory : new Set();
  const autoAttempts = previous?.autoStateVersion === 4 ? previous.autoAttempts : new Map();
  let autoNotBefore = previous?.autoStateVersion === 4 ? previous.autoNotBefore || 0 : 0;
  let autoLastTime = previous?.autoStateVersion === 4 ? previous.autoLastTime ?? null : null;
  let autoSessionKey = previous?.autoSessionKey || '';
  let autoTimer = null, autoObserver = null, autoChecking = false;
  const visible = element => !!element && !element.disabled && element.getAttribute('aria-disabled') !== 'true' &&
    element.getClientRects().length > 0 && getComputedStyle(element).visibility !== 'hidden' && getComputedStyle(element).display !== 'none';
  function exactSkipButton(action) {
    if (action === 'BrowserNetflixSkipIntro') {
      const known = [...document.querySelectorAll('button[data-uia="player-skip-intro"], [data-uia="player-skip-intro"] button')].find(visible);
      if (known) return known;
    }
    // Exact visible labels only: never click ads, next episode, login or purchase buttons.
    const labels = action === 'BrowserNetflixSkipIntro'
      ? ['오프닝 건너뛰기', '줄거리 건너뛰기', '지난 이야기 건너뛰기', 'Skip Intro', 'Skip Recap']
      : ['오프닝 건너뛰기', '지난 이야기 건너뛰기', 'Skip Intro', 'Skip Recap'];
    return [...document.querySelectorAll('button, [role="button"]')].find(button => visible(button) &&
      labels.some(label => [button.textContent, button.getAttribute('aria-label')].some(text => text?.replace(/\s+/g, ' ').trim().toLowerCase() === label.toLowerCase())));
  }
  function skipKind(button) {
    // Netflix can reuse its skip-intro control for the recap. The displayed label
    // determines which preference and completion record apply, not that control ID.
    for (const text of [button.textContent, button.getAttribute('aria-label')]) {
      const label = text?.replace(/\s+/g, ' ').trim().toLowerCase();
      if (['오프닝 건너뛰기','skip intro'].includes(label)) return 'intro';
      if (['줄거리 건너뛰기','지난 이야기 건너뛰기','skip recap'].includes(label)) return 'recap';
    }
    const uia = button.getAttribute('data-uia');
    if (service === 'Netflix' && uia === 'player-skip-intro') return 'intro';
    if (service === 'Netflix' && uia === 'player-skip-recap') return 'recap';
    return null;
  }
  function revealSkipControls(video) {
    if (service !== 'Netflix' || !video?.dispatchEvent || !video.getBoundingClientRect) return false;
    const surface = video.closest('.watch-video') || document.querySelector('.watch-video--player-view');
    const rect = video.getBoundingClientRect();
    const x = rect.left + rect.width / 2, y = rect.top + rect.height / 2;
    const overlay = document.elementFromPoint(x, y);
    const targets = new Set([video, surface?.querySelector('[data-uia="player"]'),
      surface && overlay && surface.contains(overlay) ? overlay : null, surface]);
    for (const target of targets) {
      if (!target || !visible(target)) continue;
      for (const type of ['pointerover','pointermove','mouseover','mousemove']) {
        const options = { bubbles: true, composed: true, view: window, clientX: x, clientY: y, buttons: 0 };
        target.dispatchEvent(type.startsWith('pointer')
          ? new PointerEvent(type, { ...options, pointerId: 1, pointerType: 'mouse', isPrimary: true })
          : new MouseEvent(type, options));
      }
    }
    return true;
  }
  async function manualSkip(message, video, state) {
    const source = video.currentSrc;
    const live = () => !disposed && !state.cancelled && Date.now() < message.expiresAt &&
      location.href === message.expectedUrl && video.isConnected && video.currentSrc === source;
    const wait = () => new Promise(resolve => setTimeout(resolve, 50));
    // A hidden Netflix overlay can remove its skip button completely. Recreate
    // it on explicit key press, then resolve the current DOM rather than a cache.
    for (let i = 0; i < 16 && live(); i++) {
      if (i % 4 === 0 && revealSkipControls(video)) await wait();
      if (!live()) break;
      const videos = [...document.querySelectorAll('video')].filter(visible);
      if (videos.length !== 1 || videos[0] !== video) return 'no_player';
      const button = exactSkipButton(message.action);
      if (visible(button) && button.isConnected) {
        const kind = skipKind(button), time = video.currentTime;
        button.click();
        if (kind) {
          refreshAutoSession(video);
          autoAttempts.set(autoKey(video, kind), { kind, time, at: Date.now(), count: 1 });
        }
        return 'ok';
      }
      await wait();
    }
    return state.cancelled || disposed ? 'disabled' : location.href !== message.expectedUrl ? 'page_changed' :
      Date.now() >= message.expiresAt ? 'expired' : 'not_available';
  }
  const autoKey = (video, kind) => location.href + '\n' + (video.currentSrc || '') + '\n' + kind;
  function refreshAutoSession(video) {
    const key = location.href + '\n' + (video.currentSrc || '');
    if (autoSessionKey !== key) { autoHistory.clear(); autoAttempts.clear(); autoNotBefore = 0; autoLastTime = null; autoSessionKey = key; }
  }
  function trackPlayback(video) {
    refreshAutoSession(video);
    if (!Number.isFinite(video.currentTime)) return;
    // Re-arm only after real backward movement, not when controls hide/reappear.
    // Ignore small decoder time corrections; wait for the seek UI to settle.
    if (Number.isFinite(autoLastTime) && video.currentTime < autoLastTime - 0.5) {
      autoHistory.clear();
      autoAttempts.clear();
      autoNotBefore = Date.now() + 1000;
    }
    autoLastTime = video.currentTime;
  }
  function rememberSkip(key) {
    autoHistory.add(key);
    if (autoHistory.size > 64) autoHistory.delete(autoHistory.values().next().value);
  }
  function episodeBlocksAutoSkip() {
    // A hidden tab may deliver the episode-command reply late. Its old document
    // must not block auto skip after navigation has already reached the next one.
    return [...pendingEpisodes.values()].some(state => state.url === location.href && Date.now() < state.expiresAt);
  }
  async function checkAutoSkip() {
    if (disposed || autoChecking || episodeBlocksAutoSkip() || !['Netflix','Disney+'].includes(service)) return;
    if (service === 'Netflix' && !/^\/watch\/\d+/.test(location.pathname)) return;
    const videos = [...document.querySelectorAll('video')].filter(visible);
    if (videos.length !== 1 || videos[0].seeking || videos[0].readyState < 2) return;
    const video = videos[0], url = location.href;
    trackPlayback(video);
    if (video.paused || video.ended) return;
    const buttons = [...document.querySelectorAll('button, [role="button"]')];
    for (const [key, attempt] of autoAttempts) {
      const elapsed = Math.max(0, (Date.now() - attempt.at) / 1000);
      const progressed = Number.isFinite(video.currentTime) && Number.isFinite(attempt.time) &&
        video.currentTime - attempt.time > elapsed * Math.max(1, video.playbackRate || 1) + 2;
      // Hiding player controls alone is not proof that playback skipped.
      if (progressed) {
        rememberSkip(key);
        autoAttempts.delete(key);
        // The next skip control may already be rendered while the preceding seek
        // is settling. Do not let that seek confirm two different skip actions.
        autoNotBefore = Date.now() + 1000;
      }
    }
    if (Date.now() < autoNotBefore) return;
    const candidates = buttons.filter(b => {
      const kind = skipKind(b), key = autoKey(video, kind), attempt = autoAttempts.get(key);
      return kind && (visible(b) || service === 'Netflix') && !b.disabled && b.getAttribute('aria-disabled') !== 'true' && !autoHistory.has(key) &&
        ![...autoAttempts.values()].some(other => other.kind !== kind && Date.now() - other.at < 5000) &&
        (!attempt || (attempt.count < 3 && Date.now() - attempt.at >= 1500));
    });
    if (!candidates.length) return;
    autoChecking = true;
    try {
      const considered = new Set();
      for (let button of candidates) {
      const kind = skipKind(button), key = autoKey(video, kind);
      if (considered.has(kind)) continue;
      considered.add(kind);
      const requestedTime = video.currentTime;
      let permit = await chrome.runtime.sendMessage({ type: 'nuv-auto-skip-check', kind, expectedUrl: url });
      if (permit?.allowed !== true) continue;
      if (!disposed && location.href === url && !episodeBlocksAutoSkip() && revealSkipControls(video)) {
        await new Promise(resolve => setTimeout(resolve, 50));
        if (disposed || location.href !== url || episodeBlocksAutoSkip()) return;
        button = [...document.querySelectorAll('button, [role="button"]')].find(b => visible(b) && skipKind(b) === kind);
        if (!button) continue;
        // Permission/settings may change while the overlay is being remounted.
        permit = await chrome.runtime.sendMessage({ type: 'nuv-auto-skip-check', kind, expectedUrl: url });
      }
      if (disposed || episodeBlocksAutoSkip() || permit?.allowed !== true || permit.kind !== kind || permit.expectedUrl !== url ||
          !Number.isSafeInteger(permit.expiresAt) || permit.expiresAt <= Date.now() || permit.expiresAt > Date.now() + 1500 ||
          location.href !== url || autoKey(video, kind) !== key || autoHistory.has(key) || video.paused || video.ended || video.seeking || video.readyState < 2 || video.currentTime < requestedTime - 0.5 ||
          !visible(video) || !visible(button) || !button.isConnected || skipKind(button) !== kind) return;
      const currentVideos = [...document.querySelectorAll('video')].filter(visible);
      if (currentVideos.length !== 1 || currentVideos[0] !== video) return;
      // A click is only an attempt. Retry a temporarily unresponsive control a
      // bounded number of times, obtaining a fresh authorization for every try.
      // Expired attempts of another kind cannot claim a subsequent action's seek.
      for (const [oldKey, attempt] of autoAttempts) if (attempt.kind !== kind) autoAttempts.delete(oldKey);
      autoAttempts.set(key, { kind, at: Date.now(), time: video.currentTime,
        count: (autoAttempts.get(key)?.count || 0) + 1 });
      button.click();
      break;
      }
    } catch { /* A disconnected or replaced extension must never execute offline. */ }
    finally { autoChecking = false; }
  }
  const listener = (message, sender, respond) => {
    if (disposed) return false;
    if (sender.id === chrome.runtime.id && message?.type === 'nuv-probe-v2') {
      respond({ version, url: location.href, netflixEpisodes: service === 'Netflix' && !!globalThis.NuvNetflixEpisodes }); return false;
    }
    if (sender.id === chrome.runtime.id && message?.type === 'nuv-cancel-v2' && pendingEpisodes.has(message.id)) {
      pendingEpisodes.get(message.id).cancelled = true;
      respond({ code: 'disabled' }); return false;
    }
    if (sender.id !== chrome.runtime.id || message?.type !== 'nuv-execute-v2') return false;
    if (message.expectedUrl !== location.href) { respond({ code: 'page_changed' }); return false; }
    if (!Object.hasOwn(actions, message.action) || actions[message.action] !== service || message.service !== service ||
        !/^[0-9a-f]{32}$/.test(message.id)) { respond({ code: 'error' }); return false; }
    if (!Number.isSafeInteger(message.expiresAt) || message.expiresAt <= Date.now() || message.expiresAt > Date.now() + 5000) {
      respond({ code: 'expired' }); return false;
    }
    if (seen.has(message.id)) { respond({ code: 'duplicate' }); return false; }
    seen.add(message.id);
    if (seen.size > 128) seen.delete(seen.values().next().value);
    try {
      const videos = [...document.querySelectorAll('video')].filter(visible);
      if (videos.length !== 1) { respond({ code: 'no_player' }); return false; }
      if (message.action === 'BrowserNetflixSkipIntro' || message.action === 'BrowserDisneySkipIntro') {
        if (pendingEpisodes.size) { respond({ code: 'episode_busy' }); return false; }
        const state = { cancelled: false, url: location.href, expiresAt: message.expiresAt };
        pendingEpisodes.set(message.id, state);
        manualSkip(message, videos[0], state).then(code => respond({ code }), () => respond({ code: 'error' }))
          .finally(() => { pendingEpisodes.delete(message.id); void checkAutoSkip(); });
        return true;
      }
      if (message.action === 'BrowserNetflixPreviousEpisode' || message.action === 'BrowserNetflixNextEpisode') {
        if (!globalThis.NuvNetflixEpisodes) { respond({ code: 'no_receiver' }); return false; }
        const state = { cancelled: false, url: location.href, expiresAt: message.expiresAt };
        const steps = [];
        pendingEpisodes.set(message.id, state);
        globalThis.NuvNetflixEpisodes.execute(message.action === 'BrowserNetflixNextEpisode' ? 1 : -1, message.expiresAt, () => disposed || state.cancelled,
          step => { if (steps.length < 24) steps.push(step); })
          .then(code => respond({ code: state.cancelled ? 'disabled' : code, episodeSteps: steps }), () => respond({ code: 'error', episodeSteps: steps }))
          .finally(() => { pendingEpisodes.delete(message.id); void checkAutoSkip(); });
        return true;
      }
      if (message.action.endsWith('Mute')) videos[0].muted = !videos[0].muted;
      else {
        let button;
        if (message.action === 'BrowserYouTubeNext') button = document.querySelector('.ytp-next-button');
        else if (message.action === 'BrowserYouTubePrevious') button = document.querySelector('.ytp-prev-button');
        else button = exactSkipButton(message.action);
        if (!visible(button)) { respond({ code: 'not_available' }); return false; }
        const kind = skipKind(button);
        button.click();
        if (kind) { refreshAutoSession(videos[0]); rememberSkip(autoKey(videos[0], kind)); }
      }
      // 'ok' means DOM operation dispatched, not confirmed playback progression.
      respond({ code: 'ok' });
    } catch { respond({ code: 'error' }); }
    return false;
  };
  globalThis.NuvPlayerController = { version, seen, autoStateVersion: 4, autoHistory, autoAttempts, get autoLastTime() { return autoLastTime; }, get autoNotBefore() { return autoNotBefore; }, get autoSessionKey() { return autoSessionKey; }, active: true, dispose() {
    this.active = false;
    disposed = true;
    for (const state of pendingEpisodes.values()) state.cancelled = true;
    pendingEpisodes.clear();
    if (autoTimer !== null) clearInterval(autoTimer);
    autoObserver?.disconnect();
    document.removeEventListener?.('playing', checkAutoSkip, true);
    document.removeEventListener?.('timeupdate', checkAutoSkip, true);
    document.removeEventListener?.('seeked', checkAutoSkip, true);
    try { chrome.runtime.onMessage.removeListener(listener); } catch {}
  }};
  chrome.runtime.onMessage.addListener(listener);
  if (['Netflix','Disney+'].includes(service) && typeof chrome.runtime.sendMessage === 'function') {
    autoTimer = setInterval(checkAutoSkip, 500);
    // New skip buttons can appear in a background tab whose timers are throttled.
    if (typeof MutationObserver === 'function' && document.documentElement) {
      autoObserver = new MutationObserver(() => { void checkAutoSkip(); });
      autoObserver.observe(document.documentElement, { childList: true, subtree: true, characterData: true,
        attributes: true, attributeFilter: ['aria-label','aria-disabled','disabled','hidden','class','style','data-uia'] });
    }
    document.addEventListener?.('playing', checkAutoSkip, true);
    document.addEventListener?.('timeupdate', checkAutoSkip, true);
    document.addEventListener?.('seeked', checkAutoSkip, true);
  }
})();
