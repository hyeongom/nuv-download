// Tab-scoped input only. No native host, OS mouse input, activation, or general
// protocol-command relay is exposed to content scripts.
export function createYouTubeBackgroundControl(api, authorize, allowedNow, service = 'YouTube') {
  if (!['YouTube','치지직'].includes(service)) throw new Error('unsupported_service');
  const chzzk = service === '치지직', prefix = chzzk ? 'nuv-chzzk' : 'nuv-youtube';
  const origin = chzzk ? 'https://chzzk.naver.com' : 'https://www.youtube.com';
  const busy = new Map();
  const pausedKey = 'youtubeBackgroundPaused';
  let lastCode = 'waiting', wasAllowed = false;
  const isYouTube = value => { try { return new URL(value).origin === origin; } catch { return false; } };
  const isWatch = value => { try { const u = new URL(value); return u.origin === origin && (chzzk ? /^\/(video\/\d+|live\/[a-f0-9]{32})\/?$/.test(u.pathname) : u.pathname === '/watch'); } catch { return false; } };
  async function enabled() {
    const [session, permission] = await Promise.all([
      api.storage.session.get(pausedKey),
      api.permissions.contains({ permissions: ['debugger'] })
    ]);
    return allowedNow() && !session[pausedKey] && permission;
  }
  function point(value) {
    if (!value) return null;
    const { left, top, width, height, viewportWidth, viewportHeight } = value;
    if (![left,top,width,height,viewportWidth,viewportHeight].every(Number.isFinite) ||
        left < 0 || top < 0 || width < 5 || width > 600 || height < 5 || height > 200 ||
        viewportWidth < 200 || viewportWidth > 16000 || viewportHeight < 150 || viewportHeight > 16000 ||
        left + width > viewportWidth || top + height > viewportHeight) return null;
    return { x: left + width / 2, y: top + height / 2 };
  }
  async function detach(run) {
    if (!run.attached) return;
    run.attached = false;
    if (run.focusEmulated) {
      try { await api.debugger.sendCommand({tabId:run.id},'Emulation.setFocusEmulationEnabled',{enabled:false}); } catch {}
      run.focusEmulated = false;
    }
    try { await api.debugger.detach({ tabId: run.id }); } catch { /* Already closed/detached. */ }
  }
  function cancelAll() { for (const run of busy.values()) { run.cancelled = true; void detach(run); } }
  async function wake() {
    const tabs = await api.tabs.query({url:origin+'/*'});
    await Promise.allSettled(tabs.map(t => api.tabs.sendMessage(t.id,{type:prefix+'-tab-wake'},{frameId:0})));
  }
  async function sync() {
    const active = allowedNow(), changed = active !== wasAllowed;
    wasAllowed = active;
    if (!active) cancelAll();
    else if (changed) await wake();
  }
  async function click(message, sender) {
    const id = sender.tab?.id, url = message.expectedUrl;
    if (sender.id !== api.runtime.id || sender.frameId !== 0 || !Number.isInteger(id) ||
        !sender.documentId || !isYouTube(sender.url) || !isWatch(url)) return { code: 'unavailable' };
    if (busy.has(id)) return { code: 'busy', retryAfterMs: 150 };
    const run = { id, attached: false, cancelled: false, inputSent: false, released: false };
    busy.set(id, run);
    const timer = setTimeout(() => { run.cancelled = true; void detach(run); }, 5000);
    async function current() {
      if (run.cancelled || !await enabled()) return null;
      const permit = await authorize({ kind: 'ad', expectedUrl: url, action: message.action, requestId: message.requestId }, sender);
      if (!permit?.allowed || (await api.tabs.get(id)).url !== url) { lastCode='selection_or_connection'; return null; }
      const ready = await api.tabs.sendMessage(id, { type: prefix+'-tab-ready', expectedUrl: url, action: message.action, requestId: message.requestId }, { documentId: sender.documentId });
      if (run.cancelled || !ready?.ready || ready.url !== url ||
          ready.version !== api.runtime.getManifest().version || !allowedNow() ||
          !await enabled() || (await api.tabs.get(id)).url !== url) return null;
      const p = point(ready.geometry);
      if (!p) lastCode='button_not_ready';
      return p ? {...p, hover: chzzk && ready.hover === true} : null;
    }
    try {
      if (!await current()) return { code: 'not_ready' };
      try { await api.debugger.attach({ tabId: id }, '1.3'); run.attached = true; }
      catch { return { code: 'debugger_busy' }; }
      if (run.cancelled || !await enabled()) return {code:'cancelled'};
      // Keep only this page responsive while sending input. This does not
      // activate its OS window or switch the user's selected browser tab.
      await api.debugger.sendCommand({tabId:id},'Emulation.setFocusEmulationEnabled',{enabled:true});
      run.focusEmulated = true;
      // Attaching can resize the viewport (browser notification). Re-probe now.
      let p = await current();
      if (p?.hover) {
        await api.debugger.sendCommand({tabId:id},'Input.dispatchMouseEvent',{type:'mouseMoved',x:p.x,y:p.y});
        await new Promise(resolve=>setTimeout(resolve,100));
        p = await current();
      }
      if (!p || p.hover || run.cancelled) return { code: 'cancelled', retryAfterMs: 150 };
      run.inputSent = true;
      await api.debugger.sendCommand({ tabId: id }, 'Input.dispatchMouseEvent',
        { type: 'mousePressed', x:p.x, y:p.y, button: 'left', buttons: 1, clickCount: 1 });
      if (run.cancelled || !allowedNow() || !await enabled() || (await api.tabs.get(id)).url !== url)
        return { code: 'input_unconfirmed' };
      await api.debugger.sendCommand({ tabId: id }, 'Input.dispatchMouseEvent',
        { type: 'mouseReleased', x:p.x, y:p.y, button: 'left', buttons: 0, clickCount: 1 });
      run.released = true;
      return { code: 'clicked' };
    } catch { return { code: run.inputSent ? 'input_unconfirmed' : 'unavailable' }; }
    finally {
      clearTimeout(timer);
      if (run.inputSent && !run.released && run.attached) {
        // Release outside the viewport after an interrupted press; do not leave
        // a button held or click the old coordinates on a navigated document.
        try { await api.debugger.sendCommand({tabId:id},'Input.dispatchMouseEvent',
          {type:'mouseReleased',x:-1,y:-1,button:'left',buttons:0,clickCount:0}); } catch {}
      }
      await detach(run); busy.delete(id);
    }
  }
  api.debugger.onDetach.addListener((source, reason) => {
    const run = busy.get(source.tabId);
    if (run) { run.attached = false; run.cancelled = true; }
    // Respect the browser's Cancel button: never automatically reattach.
    if (reason === 'canceled_by_user') {
      void api.storage.session.set({ [pausedKey]: true }); cancelAll();
    }
  });
  api.tabs.onUpdated.addListener((id, change) => {
    const run = busy.get(id);
    if (run && (change.url || change.status === 'loading')) { run.cancelled = true; void detach(run); }
  });
  api.tabs.onRemoved.addListener(id => { const run = busy.get(id); if (run) { run.cancelled = true; void detach(run); } });
  api.permissions.onRemoved.addListener(value => { if (value.permissions?.includes('debugger')) cancelAll(); });
  api.runtime.onMessage.addListener((m, s, reply) => {
    if (m?.type === prefix+'-tab-click') {
      click(m,s).then(value=>{if(value.code!=='not_ready')lastCode=value.code;reply(value);}, () => {lastCode='unavailable';reply({code:'unavailable'});}); return true;
    }
    if (m?.type === prefix+'-tab-feedback' && s.id===api.runtime.id && s.frameId===0 && isYouTube(s.url)) {
      if (['ad_ended','button_still_visible'].includes(m.code)) lastCode=m.code;
      reply({ok:true}); return false;
    }
    if (![prefix+'-background-status',prefix+'-background-resume'].includes(m?.type)) return false;
    if (s.id !== api.runtime.id || s.url !== api.runtime.getURL('popup.html') || s.tab) return false;
    (async () => {
      if (m.type === prefix+'-background-resume') {
        await api.storage.session.set({[pausedKey]: false});
        await wake();
      }
      const session = await api.storage.session.get(pausedKey);
      return {enabled: await enabled(), pcEnabled:allowedNow(), permission:await api.permissions.contains({permissions:['debugger']}), paused: session[pausedKey] === true, code:lastCode};
    })().then(reply, () => reply({enabled:false})); return true;
  });
  return { click, sync, cancel:cancelAll };
}
