(() => {
  if (!globalThis.chrome?.runtime?.id) return;
  const button = document.getElementById('youtube-background-resume');
  const status = document.getElementById('youtube-background-status');
  function render(value) {
    button.hidden = !value.paused;
    const reason={debugger_busy:'탭 제어에 연결하지 못했습니다. 이 영상의 F12 개발자 도구나 다른 디버깅 연결을 닫아주세요.',
      unavailable:'영상 탭에 응답하지 못했습니다. 확장 연결 상태를 확인해주세요.',
      input_unconfirmed:'입력 도중 연결이 바뀌어 결과를 확인하지 못했습니다.',
      selection_or_connection:'제어할 영상 탭 선택 또는 PC 연결 상태를 확인해주세요.',
      button_still_visible:'클릭을 보냈지만 광고 건너뛰기 버튼이 남아 있습니다.',
      ad_ended:'광고가 끝난 상태를 확인했습니다. 다음 광고를 기다립니다.',
      clicked:'클릭을 보냈습니다. 광고가 끝났는지 확인 중입니다.'}[value.code];
    status.textContent = !value.permission ? '브라우저의 debugger 권한이 없습니다. 확장 관리에서 권한을 확인해주세요.' :
      value.paused ? '브라우저에서 제어를 취소했습니다. 다시 허용하려면 아래 버튼을 누르세요.' :
      !value.pcEnabled ? 'PC NUV의 브라우저 연결을 켜주세요.' :
      '영상 제어 연결됨 · '+(reason||'자동 건너뛰기는 PC에서 선택한 항목만 작동합니다.');
  }
  button.addEventListener('click', async () => {
    button.disabled = true;
    try { await chrome.runtime.sendMessage({type:'nuv-chzzk-background-resume'}); await chrome.runtime.sendMessage({type:'nuv-youtube-background-resume'}); await refresh(); }
    catch { status.textContent = '설정을 바꾸지 못했습니다. 확장을 다시 열어주세요.'; }
    finally { button.disabled = false; }
  });
  const refresh=()=>Promise.all(['nuv-youtube-background-status','nuv-chzzk-background-status'].map(type=>chrome.runtime.sendMessage({type}))).then(([youtube,chzzk])=>render({...youtube, pcEnabled:youtube.pcEnabled||chzzk.pcEnabled,paused:youtube.paused||chzzk.paused,code:youtube.pcEnabled?youtube.code:chzzk.code}), () => {
    status.textContent = '확장 관리에서 권한과 다시 로드를 확인해주세요.';
  });
  void refresh();setInterval(refresh,1500);
})();
