// Isolated-world DOM adapter. No account API, watch-history navigation, or guessed video IDs.
(() => {
  const version = chrome.runtime.getManifest().version;
  if (globalThis.NuvNetflixEpisodes?.version === version) return;
  globalThis.NuvPlayerController?.dispose();
  let running = false, uncertainPath = null, uncertainSince = 0;
  const panels = '.watch-video [data-uia="episode-pane"], [data-uia="episode-selector"], .episode-selector, .watch-video--episodes';
  const rows = '[data-uia="episode-pane-item"][role="option"], [data-uia="episode-item"], .episode-list-item, .episode-selector-item, .episode';
  const next = '.watch-video button[data-uia="control-next"], [data-uia="next-episode-seamless-button"], [data-uia="next-episode-seamless-button-draining"], [data-uia="player-next-episode"], .button-nfplayerNextEpisode';
  const menu = '.watch-video button[data-uia="control-episodes"], [data-uia="player-episodes"], .button-nfplayerEpisodes';
  const enabled = el => !!el && !el.disabled && el.getAttribute('aria-disabled') !== 'true';
  const visible = el => {
    if (!enabled(el) || !el.isConnected || !el.getClientRects().length) return false;
    const own = getComputedStyle(el);
    if (['hidden','collapse'].includes(own.visibility)) return false;
    for(let node=el;node;node=node.parentElement) {
      const style=getComputedStyle(node);
      if(style.display==='none'||style.opacity==='0')return false;
    }
    return true;
  };
  const watchPath = () => /^\/watch\/\d+\/?$/.test(location.pathname) ? location.pathname : null;
  const pause = () => new Promise(resolve => setTimeout(resolve, 50));
  function uniqueVisible(selector, root = document) {
    const items = [...root.querySelectorAll(selector)].filter(visible);
    return items.length === 1 ? items[0] : null;
  }
  function episodeList() {
    // Nested wrappers must not count the same episode list twice.
    const lists = [...document.querySelectorAll(panels)].filter(visible).map(panel =>
      [...panel.querySelectorAll(rows)].filter(row => !row.parentElement?.closest(rows))
    ).filter(list => list.length > 0);
    const unique = lists.filter((list, index) => !lists.slice(0, index).some(other =>
      list.length === other.length && list.every((item, i) => item === other[i])));
    return unique.length === 1 ? unique[0] : null;
  }
  function current(row, path) {
    // aria-selected is the preview/highlight, not proof of what is playing.
    if (row.matches('[data-uia="episode-pane-item"]') && row.querySelector('[data-uia="episode-pane-item-now-playing"]')) return true;
    if (row.matches('[aria-current="true"], [aria-current="page"], .current, .is-current, .playing')) return true;
    const links = [...row.querySelectorAll('a[href]')];
    if (row.matches('a[href]')) links.push(row);
    return links.some(link => {
      try { const url = new URL(link.getAttribute('href'), location.href); return url.origin === location.origin && url.pathname === path; }
      catch { return false; }
    });
  }
  const seasonOptions = () => [...document.querySelectorAll('.watch-video [data-uia="season-pane"] [role="option"]')];
  const selectedSeasonNode = () => {
    const selected = seasonOptions().filter(el => el.getAttribute('aria-selected') === 'true');
    return selected.length === 1 ? selected[0] : null;
  };
  const seasonNumber = el => {
    const text = el?.textContent.replace(/\s+/g, ' ').trim() || '';
    const match = /^(?:시즌\s*(\d+)|Season\s+(\d+)|(\d+)\s*시즌)$/i.exec(text);
    return match ? Number(match[1] || match[2] || match[3]) : null;
  };
  async function execute(direction, expiresAt, cancelled = () => false, record = () => {}) {
    // Fixed stage names only: no page text, titles, URLs or identifiers.
    const stage = value => { try { record(value); } catch {} };
    stage('started');
    const original = watchPath();
    if (!original) return 'no_player';
    if (running) return 'episode_busy';
    if (uncertainPath !== original) { uncertainPath = null; uncertainSince = 0; }
    const recovering = uncertainPath === original;
    running = true;
    let clicked = false;
    let episodePlayButton = null;
    const live = () => !cancelled() && Date.now() < expiresAt && watchPath() === original;
    const stopped = () => cancelled() ? 'disabled' : watchPath() !== original ? 'page_changed' : 'expired';
    const pressAndRelease = (element, stillCurrent) => {
      const rect = element.getBoundingClientRect();
      const eventOptions = { bubbles: true, cancelable: true, composed: true,
        view: window, button: 0, clientX: rect.left + rect.width / 2,
        clientY: rect.top + rect.height / 2, detail: 1 };
      let mouseAllowed = true;
      for (const type of ['pointerdown', 'mousedown', 'pointerup', 'mouseup']) {
        if (!live() || !visible(element) || !stillCurrent()) return;
        const pointer = type.startsWith('pointer');
        if (!pointer && !mouseAllowed) continue;
        const options = { ...eventOptions, buttons: type.endsWith('down') ? 1 : 0 };
        const event = pointer
          ? new PointerEvent(type, { ...options, pointerId: 1, pointerType: 'mouse', isPrimary: true })
          : new MouseEvent(type, options);
        const accepted = element.dispatchEvent(event);
        if (type === 'pointerdown' && !accepted) mouseAllowed = false;
      }
    };
    const waitFor = async (read, milliseconds) => {
      const until = Math.min(expiresAt, Date.now() + milliseconds);
      do { if (!live()) return null; const found = read(); if (found) return found; await pause(); } while (Date.now() < until);
      return null;
    };
    const hover = element => {
      if (!live() || !visible(element)) return;
      const rect = element.getBoundingClientRect();
      const options = { bubbles: true, cancelable: true, composed: true, view: window,
        clientX: rect.left + rect.width / 2, clientY: rect.top + rect.height / 2, buttons: 0 };
      for (const type of ['pointerover', 'pointerenter', 'pointermove', 'mouseover', 'mouseenter', 'mousemove']) {
        if (!live() || !visible(element)) return;
        const init = { ...options, bubbles: !type.endsWith('enter') };
        element.dispatchEvent(type.startsWith('pointer')
          ? new PointerEvent(type, { ...init, pointerId: 1, pointerType: 'mouse', isPrimary: true })
          : new MouseEvent(type, init));
      }
    };
    const revealControls = () => {
      // Wake the player with in-player coordinates. A zero-coordinate event on
      // the outer wrapper misses handlers on the video/control overlay.
      const video = uniqueVisible('video');
      if (!video) return;
      const surface = document.querySelector('.watch-video, .watch-video--player-view');
      const rect = video.getBoundingClientRect();
      const overlay = document.elementFromPoint(rect.left + rect.width / 2, rect.top + rect.height / 2);
      const targets = new Set([video, surface?.querySelector('[data-uia="player"]'),
        surface && overlay && surface.contains(overlay) ? overlay : null, surface]);
      for (const target of targets) if (target) hover(target);
    };
    try {
      if (recovering) {
        // An explicit NEW key press may recover after a quiet period. Never
        // replay the old command or clear the lock just because a timer elapsed.
        stage('checking_playback_after_unconfirmed');
        if (Date.now() - uncertainSince < 2500) return 'episode_busy';
        const stableVideo = () => {
          const videos = [...document.querySelectorAll('video')].filter(visible);
          return videos.length === 1 && videos[0].readyState >= 2 && !videos[0].seeking ? videos[0] : null;
        };
        const video = stableVideo();
        if (!video) return 'episode_busy';
        const source = video.currentSrc;
        for (let i = 0; i < 6; i++) {
          await pause();
          if (!live()) return stopped();
          if (stableVideo() !== video || video.currentSrc !== source) return 'episode_busy';
        }
        stage('rechecking_episode_list');
        // Recovery always resolves an adjacent row from the current episode
        // list. Never blindly press a dynamic Next button after an uncertain move.
      }
      stage('locating_controls');
      // Preparation may repeat while a cold player mounts its controls. Never
      // repeat a playback click, reload the page, or steal window focus.
      // An inactive player can retain controls in the DOM while fading them
      // out. Wake it once even if a control already has a layout rectangle.
      let lastReveal = 0;
      if (!episodeList()) { revealControls(); lastReveal = Date.now(); }
      const controls = await waitFor(() => {
        const read = () => ({ target: direction === 1 && !recovering ? uniqueVisible(next) : null,
          list: episodeList(), opener: uniqueVisible(menu) });
        let found = read();
        if (found.target || found.list || found.opener) return found;
        if (Date.now() - lastReveal >= 200) { lastReveal = Date.now(); revealControls(); }
        if (!live()) return null;
        found = read();
        return found.target || found.list || found.opener ? found : null;
      }, 1100);
      if (!controls) return live() ? 'episode_unavailable' : stopped();
      let target = controls.target;
      if (!target) {
        let list = episodeList();
        if (!list) {
          stage('opening_episode_menu');
          const opener = uniqueVisible(menu);
          if (!opener) return live() ? 'episode_unavailable' : stopped();
          hover(opener);
          list = await waitFor(episodeList, 200);
          if (!list && live() && visible(opener)) {
            opener.click();
            list = await waitFor(episodeList, 700);
          }
        }
        if (!list) { stage('episode_list_missing'); return live() ? 'episode_unavailable' : stopped(); }
        stage('episode_list_found');
        const indices = list.flatMap((row, i) => current(row, original) ? [i] : []);
        if (indices.length !== 1) { stage('current_episode_unclear'); return 'episode_unavailable'; }
        stage('current_episode_found');
        let targetIndex = indices[0] + direction;
        let row = list[targetIndex];
        let crossedSeason = false;
        if (!row && (direction === 1 || direction === -1)) {
          // Only cross a proven numbered-season boundary. Never choose trailers,
          // specials, recommendations, or a guessed /watch URL.
          const oldSeason = selectedSeasonNode();
          const oldNumber = seasonNumber(oldSeason);
          const options = seasonOptions();
          const adjacent = options.filter(el => seasonNumber(el) === oldNumber + direction);
          if (!oldNumber || oldNumber + direction < 1 || adjacent.length !== 1) return 'episode_boundary';
          const seasonTargetNumber = oldNumber + direction;
          // A first rendered row is not necessarily episode 1 (virtualized list).
          if (direction === -1 && list[indices[0]].querySelector('[data-uia="episode-pane-item-number"]')?.textContent.trim() !== '1')
            return 'episode_unavailable';
          const oldRows = list;
          const targetSeason = () => {
            const matches = seasonOptions().filter(el => seasonNumber(el) === seasonTargetNumber && visible(el));
            return matches.length === 1 ? matches[0] : null;
          };
          if (!targetSeason()) {
            const back = uniqueVisible('.watch-video [data-uia="episode-pane-back"]');
            if (!back) return 'episode_unavailable';
            const header = uniqueVisible('[data-uia="selector-episode-header"]', back) || back;
            stage('opening_season_menu');
            pressAndRelease(header, () => header.isConnected);
            if (live() && !targetSeason() && visible(header)) header.click();
            if (!await waitFor(targetSeason, 700)) return live() ? 'episode_unavailable' : stopped();
          }
          const seasonTarget = targetSeason();
          if (!live() || !seasonTarget) return live() ? 'episode_unavailable' : stopped();
          stage(direction === 1 ? 'selecting_next_season' : 'selecting_previous_season');
          pressAndRelease(seasonTarget, () => targetSeason() === seasonTarget);
          if (live() && seasonNumber(selectedSeasonNode()) !== seasonTargetNumber && targetSeason() === seasonTarget) seasonTarget.click();
          let previousListSignature = '', previousListSince = 0;
          const newList = await waitFor(() => {
            if (seasonNumber(selectedSeasonNode()) !== seasonTargetNumber) return null;
            const fresh = episodeList();
            if (!fresh || fresh.some(el => oldRows.includes(el)) || fresh.some(el => current(el, original))) return null;
            const first = fresh[0];
            // A newly loaded list must start with episode 1, not a virtualized fragment.
            if (first.querySelector('[data-uia="episode-pane-item-number"]')?.textContent.trim() !== '1') return null;
            if (direction === -1 && !fresh.every((item,i) =>
              item.querySelector('[data-uia="episode-pane-item-number"]')?.textContent.trim() === String(i+1))) return null;
            if (direction === -1) {
              // Reach the bottom and let a late list update settle before choosing
              // the last row. Never use a virtualized fragment missing episode 1.
              fresh.at(-1).scrollIntoView({block:'nearest',behavior:'instant'});
              const signature = fresh.map(item => item.querySelector('[data-uia="episode-pane-item-number"]').textContent.trim()).join(',');
              if (signature !== previousListSignature) { previousListSignature = signature; previousListSince = Date.now(); }
              if (Date.now() - previousListSince < 250) return null;
            }
            return fresh;
          }, 1100);
          if (!newList) return live() ? 'episode_unavailable' : stopped();
          list = newList; targetIndex = direction === 1 ? 0 : list.length - 1; row = list[targetIndex]; crossedSeason = true;
          if (direction === -1) row.scrollIntoView({block:'nearest',behavior:'instant'});
          stage(direction === 1 ? 'next_season_first_episode_found' : 'previous_season_last_episode_found');
        }
        if (!row) return 'episode_boundary';
        if (!visible(row)) return 'episode_unavailable';
        // Click only the adjacent entry, never a synopsis/menu/recommendation outside this list.
        if (row.matches('[data-uia="episode-pane-item"][role="option"]')) {
          // Keep identity locally, never put text/season labels in diagnostics.
          // React may replace the row when its preview is selected.
          const number = item => {
            const value = item.querySelector('[data-uia="episode-pane-item-number"]')?.textContent.trim() || '';
            return /^\d{1,4}$/.test(value) ? value : null;
          };
          const numbers = list.map(number);
          const canIdentify = numbers.every(Boolean) && new Set(numbers).size === numbers.length;
          const selectedSeason = selectedSeasonNode;
          const season = selectedSeason();
          const label = item => item?.textContent.replace(/\s+/g, ' ').trim().slice(0, 160) || '';
          const seasonLabel = label(season);
          let replacementReported = false;
          const resolveRow = () => {
            const latest = episodeList();
            if (!latest || latest.length !== list.length) return null;
            const latestSeason = selectedSeason();
            const sameSeason = season && (seasonLabel ? label(latestSeason) === seasonLabel : latestSeason === season);
            if (season && !sameSeason) return null;
            if (crossedSeason && !sameSeason) return null;
            if (canIdentify && !latest.every((item,i) => number(item) === numbers[i])) return null;
            if (latest[targetIndex] === row && row.isConnected) return row;
            if (!canIdentify || !latest.every((item, i) => number(item) === numbers[i])) return null;
            // If no season selector exists, the playback marker must still
            // identify the original current episode in the replacement list.
            if (!sameSeason) {
              const currentIndices = latest.flatMap((item,i) => current(item,original) ? [i] : []);
              if (currentIndices.length !== 1 || currentIndices[0] !== indices[0]) return null;
            }
            if (!replacementReported) { stage('adjacent_row_replaced'); replacementReported = true; }
            return latest[targetIndex];
          };
          // The observed layout keeps each play button in a hidden preview.
          // Reveal only the adjacent row and click its actual play button.
          // Only this identified adjacent episode may be selected; never a
          // generic option or the season/back navigation entry.
          if (!live()) return stopped();
          stage('hovering_adjacent_episode');
          // The number is inside the episode header. Events dispatched on the
          // outer option cannot reach listeners attached to that inner header.
          const headerTarget = item => uniqueVisible('[data-uia="episode-pane-item-number"]', item) || item;
          const hoverTarget = headerTarget(row);
          hoverTarget.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }));
          hoverTarget.dispatchEvent(new MouseEvent('mouseenter', { bubbles: false }));
          hoverTarget.dispatchEvent(new MouseEvent('mousemove', { bubbles: true }));
          const playButton = () => {
            const fresh = resolveRow();
            // The observed .play-button identifies the action. Require actual
            // visibility, not the optional preview-open wrapper state.
            return fresh && visible(fresh) ? uniqueVisible('button.play-button', fresh) : null;
          };
          episodePlayButton = playButton;
          target = await waitFor(playButton, 250);
          const selection = !target && live() ? resolveRow() : null;
          if (!target && live() && visible(selection)) {
            // Some layouts select/expand an episode on click, not hover.
            // Selecting may itself navigate, so count it as a possible play
            // request and never issue another command if its outcome is unclear.
            clicked = true;
            stage('selecting_adjacent_episode');
            const opener = headerTarget(selection);
            if (opener !== selection) stage('selecting_episode_number');
            // HTMLElement.click() omits press/release handlers. Support those
            // headers too, without sending another click if release already
            // opened the preview. These remain synthetic, untrusted events.
            const stillSameHeader = () => {
              const fresh = resolveRow();
              return live() && visible(opener) && fresh && headerTarget(fresh) === opener;
            };
            stage('pressing_episode_header');
            pressAndRelease(opener, stillSameHeader);
            if (stillSameHeader() && !playButton()) opener.click();
            target = await waitFor(playButton, 700);
            const changed = watchPath();
            if (changed && changed !== original) { stage('navigation_confirmed'); return 'episode_moved'; }
            if (!target) {
              const fresh = resolveRow();
              stage(!fresh ? 'adjacent_row_unverified' : fresh.querySelector('button.play-button') ? 'play_button_hidden' : 'play_button_absent');
              stage('preview_play_button_missing');
              uncertainPath = original;
              return live() ? 'episode_unconfirmed' : stopped();
            }
          }
        } else {
          target = row.matches('button, a[href], [role="button"]') ? row : uniqueVisible('button, a[href], [role="button"]', row);
        }
        if (!target) return live() ? 'episode_unavailable' : stopped();
        stage('play_button_found');
      } else {
        stage('next_button_found');
      }
      if (!live()) return stopped();
      if (!visible(target)) return 'episode_unavailable';
      clicked = true;
      if (episodePlayButton) {
        stage('pressing_episode_play');
        // Use the same input sequence as preview selection, but only on the
        // verified visible play button. Never continue on a detached/replaced
        // target, after cancellation, or once navigation has begun.
        const stillSamePlay = () => live() && visible(target) && episodePlayButton() === target;
        pressAndRelease(target, stillSamePlay);
        if (stillSamePlay()) { stage('play_clicked'); target.click(); }
      } else { stage('play_clicked'); target.click(); }
      const until = Math.min(expiresAt, Date.now() + 1400);
      do {
        if (cancelled()) return 'disabled';
        const changed = watchPath();
        if (changed && changed !== original) { stage('navigation_confirmed'); return 'episode_moved'; }
        await pause();
      } while (Date.now() < until);
      // A slow React navigation may still finish. A later explicit request must
      // first observe stable playback and re-read the current episode list.
      uncertainPath = original;
      stage('navigation_unconfirmed');
      return 'episode_unconfirmed';
    } catch {
      stage('exception');
      if (clicked) uncertainPath = original;
      return clicked ? 'episode_unconfirmed' : 'episode_unavailable';
    } finally {
      if (clicked && watchPath() === original) { uncertainPath = original; uncertainSince = Date.now(); }
      running = false;
    }
  }
  function controlState(action) {
    if(!watchPath() || !['BrowserNetflixPreviousEpisode','BrowserNetflixNextEpisode','BrowserNetflixSkipIntro'].includes(action))return null;
    const video=uniqueVisible('video'),surface=document.querySelector('.watch-video, .watch-video--player-view');
    if(!video||!surface||!surface.contains(video))return null;
    let ready=!!episodeList()||!!uniqueVisible(menu);
    if(action==='BrowserNetflixNextEpisode')ready=ready||!!uniqueVisible(next);
    if(action==='BrowserNetflixSkipIntro')ready=[...surface.querySelectorAll('button, [role="button"]')].some(button=>visible(button)&&
      [button.textContent,button.getAttribute('aria-label')].some(text=>/^(오프닝 건너뛰기|줄거리 건너뛰기|지난 이야기 건너뛰기|skip intro|skip recap)$/i.test(text?.replace(/\s+/g,' ').trim()||'')));
    const r=video.getBoundingClientRect(),x=r.left+r.width/2,y=r.top+r.height/2,hit=document.elementFromPoint(x,y);
    const geometry=hit&&surface.contains(hit)&&x>=8&&y>=8&&x+8<innerWidth&&y+8<innerHeight?
      {left:x-4,top:y-4,width:8,height:8,viewportWidth:innerWidth,viewportHeight:innerHeight}:null;
    return {ready,geometry,background:document.visibilityState==='hidden'||document.hasFocus?.()===false};
  }
  globalThis.NuvNetflixEpisodes = Object.freeze({ version, execute, controlState });
})();
