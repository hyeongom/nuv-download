(() => {
  if(location.hostname!=='www.youtube.com')return;
  const version=chrome.runtime.getManifest().version;
  if(globalThis.NuvYouTubeBackground?.version===version)return;
  globalThis.NuvYouTubeBackground?.dispose();
  globalThis.NuvYouTubeForeground?.dispose();delete globalThis.NuvYouTubeForeground;
  let disposed=false,pending=false,queued=false,timer=null,state=null;
  const selectors='.ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-skip-ad-button';
  const labels=new Set(['건너뛰기','광고 건너뛰기','skip','skip ad','skip ads']);
  const visible=e=>e?.isConnected && e.getClientRects().length>0 && !['hidden','collapse'].includes(getComputedStyle(e).visibility) && getComputedStyle(e).display!=='none';
  function usable(e){
    if(!visible(e)||e.disabled||e.getAttribute('aria-disabled')==='true'||getComputedStyle(e).pointerEvents==='none')return false;
    for(let p=e;p;p=p.parentElement)if(getComputedStyle(p).display==='none'||Number(getComputedStyle(p).opacity)===0)return false;
    return true;
  }
  function inspect(){
    if(location.pathname!=='/watch')return null;
    const players=[...document.querySelectorAll('.html5-video-player.ad-showing')].filter(visible);
    if(players.length!==1)return null;
    const player=players[0],videos=[...player.querySelectorAll('video')].filter(visible);
    if(videos.length!==1)return null;
    const video=videos[0];
    const buttons=[...player.querySelectorAll('button,[role="button"]')].filter(b=>b.tagName!=='A'&&!b.hasAttribute('href')&&b.closest('.html5-video-player')===player && usable(b) &&
      (b.matches(selectors)||[b.textContent,b.getAttribute('aria-label')].some(t=>labels.has(String(t||'').replace(/\s+/g,' ').trim().toLowerCase()))));
    const unique=buttons.filter(b=>!buttons.some(other=>other!==b&&b.contains(other)));
    const base={player,video,url:location.href,source:video.currentSrc};
    if(unique.length!==1)return base;
    const button=unique[0],r=button.getBoundingClientRect(),hit=document.elementFromPoint(r.left+r.width/2,r.top+r.height/2);
    if(!hit||!(hit===button||button.contains(hit)))return base;
    return {...base,button,geometry:{left:r.left,top:r.top,width:r.width,height:r.height,viewportWidth:innerWidth,viewportHeight:innerHeight,scale:devicePixelRatio}};
  }
  // An enabled skip button is usable even if the ad video is paused.
  const ready=c=>!!c?.button && !c.video.ended && !c.video.seeking && c.video.readyState>=2;
  const feedback=code=>{void chrome.runtime.sendMessage({type:'nuv-youtube-tab-feedback',code}).catch(()=>{});};
  function schedule(delay){if(timer!==null)clearTimeout(timer);timer=setTimeout(()=>{timer=null;void check();},delay);}
  async function check(){
    if(disposed)return;
    if(pending){queued=true;return;}
    const c=inspect();
    if(!c){if(state?.awaiting)feedback('ad_ended');state=null;return;}
    if(!state||state.video!==c.video||state.player!==c.player||state.url!==c.url||state.source!==c.source||c.video.currentTime<state.time-0.5)
      state={...c,time:c.video.currentTime,done:false,notBefore:0,failures:0,clicks:0,awaiting:false};
    state.time=c.video.currentTime;
    if(state.done||!ready(c)||Date.now()<state.notBefore)return;
    if(state.awaiting){
      state.awaiting=false;
      if(state.clicks>=2||state.clickedButton!==c.button){state.done=true;feedback('button_still_visible');return;}
    }
    const run=state;pending=true;queued=false;
    try{
      const result=await chrome.runtime.sendMessage({type:'nuv-youtube-tab-click',expectedUrl:c.url});
      if(disposed)return;
      if(state!==run){if(result?.code==='clicked'&&!inspect())feedback('ad_ended');return;}
      if(result?.code==='clicked'){
        run.clicks++;run.clickedButton=c.button;run.awaiting=true;
        run.notBefore=Date.now()+1200;schedule(1200);
      }else if(result?.code==='input_unconfirmed')run.done=true;
      else {
        const transient=['not_ready','busy','cancelled'].includes(result?.code);
        if(!transient)run.failures++;
        const delay=transient ? Math.min(1500,Math.max(100,Number(result.retryAfterMs)||500)) : Math.min(30000,1000*2**Math.min(run.failures,5));
        run.notBefore=Date.now()+delay;schedule(delay);
      }
    }catch{run.notBefore=Date.now()+5000;schedule(5000);}
    finally{pending=false;if(queued&&!disposed){queued=false;void check();}}
  }
  const listener=(m,s,r)=>{
    if(!disposed&&s.id===chrome.runtime.id&&m?.type==='nuv-youtube-tab-wake'){
      if(state)state.notBefore=0;void check();r({ok:true});return false;
    }
    if(disposed||s.id!==chrome.runtime.id||m?.type!=='nuv-youtube-tab-ready'||m.expectedUrl!==location.href)return false;
    const c=inspect();const ok=ready(c)&&!state?.done;
    r({url:location.href,version,ready:ok,geometry:ok?c.geometry:null,fullscreen:!!document.fullscreenElement});return false;
  };
  chrome.runtime.onMessage.addListener(listener);
  const wake=()=>{void check();};
  for(const event of ['visibilitychange','fullscreenchange'])document.addEventListener(event,wake,true);
  window.addEventListener('focus',wake);
  globalThis.NuvYouTubeBackground={version,check,dispose(){disposed=true;if(timer!==null)clearTimeout(timer);chrome.runtime.onMessage.removeListener(listener);for(const e of ['visibilitychange','fullscreenchange'])document.removeEventListener(e,wake,true);window.removeEventListener('focus',wake);}};
})();
