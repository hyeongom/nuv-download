// Only controls exposed by the CHZZK player are used. No ad removal, seeking,
// guessed video IDs, browser history manipulation or arbitrary page clicks.
(() => {
  if (location.origin !== 'https://chzzk.naver.com') return;
  const version = chrome.runtime.getManifest().version;
  if (globalThis.NuvChzzk?.version === version) return;
  globalThis.NuvChzzk?.dispose();
  const actions = new Set(['BrowserChzzkPrevious','BrowserChzzkNext','BrowserChzzkSkipAd']);
  let disposed=false, pending=false, timer=null, state=null, manual=false;
  const visible = e => e?.isConnected && e.getClientRects().length > 0 &&
    !['none'].includes(getComputedStyle(e).display) && !['hidden','collapse'].includes(getComputedStyle(e).visibility);
  function usable(e) {
    if (!visible(e) || e.disabled || e.getAttribute('aria-disabled')==='true' || getComputedStyle(e).pointerEvents==='none') return false;
    for(let p=e;p;p=p.parentElement) if(getComputedStyle(p).display==='none'||Number(getComputedStyle(p).opacity)===0)return false;
    return true;
  }
  function geometry(e) {
    const r=e.getBoundingClientRect(), hit=document.elementFromPoint(r.left+r.width/2,r.top+r.height/2);
    if(!hit || !(hit===e||e.contains(hit)) || r.left<0 || r.top<0 || r.right>innerWidth || r.bottom>innerHeight) return null;
    return {left:r.left,top:r.top,width:r.width,height:r.height,viewportWidth:innerWidth,viewportHeight:innerHeight};
  }
  function inspect(action='BrowserChzzkSkipAd', allowHover=false) {
    if(!actions.has(action)||!/^\/(video\/\d+|live\/[a-f0-9]{32})\/?$/.test(location.pathname))return null;
    if(action!=='BrowserChzzkSkipAd'&&!/^\/video\/\d+\/?$/.test(location.pathname))return null;
    const players=[...document.querySelectorAll('.pzp.pzp-pc')].filter(visible);
    if(players.length!==1)return null;
    const player=players[0], video=player.querySelector('video.webplayer-internal-video');
    if(!video)return null;
    const isAd=player.classList.contains('pzp-pc--adbreak');
    if(action==='BrowserChzzkSkipAd'&&!isAd || action!=='BrowserChzzkSkipAd'&&isAd)return null;
    // Observed CHZZK buttons: .btn_skip[data-role=skipBtn], .pzp-prev-button,
    // .pzp-next-button. Advertiser links and countdown labels are never targets.
    const selector=action==='BrowserChzzkPrevious'?'button.pzp-prev-button[aria-label="이전 영상"]':
      action==='BrowserChzzkNext'?'button.pzp-next-button[aria-label="다음 영상"]':
      '.webplayer-internal-core-ad-ui button.btn_skip[data-role="skipBtn"][aria-label="광고 SKIP"]';
    const buttons=[...player.querySelectorAll(selector)].filter(b=>b.closest('.pzp.pzp-pc')===player&&!b.hasAttribute('href'));
    const ready=buttons.filter(usable).map(button=>({button,geometry:geometry(button)})).filter(x=>x.geometry);
    const base={url:location.href,player,video};
    if(ready.length===1)return {...base,...ready[0],ready:true};
    // Reveal auto-hidden navigation controls using a tab-scoped pointer move.
    // Absent/disabled/covered controls are not treated as a successful click.
    if(allowHover && buttons.length<=1 && (buttons.length===1 ? !buttons[0].disabled && buttons[0].getAttribute('aria-disabled')!=='true' : action!=='BrowserChzzkSkipAd')) {
      const r=player.getBoundingClientRect(), x=r.left+r.width/2,y=r.top+r.height/2;
      const hit=document.elementFromPoint(x,y);
      if(hit&&player.contains(hit)&&x>=10&&y>=10&&x+10<innerWidth&&y+10<innerHeight)
        return {...base,ready:true,hover:true,geometry:{left:x-5,top:y-5,width:10,height:10,viewportWidth:innerWidth,viewportHeight:innerHeight}};
    }
    return {...base,ready:false};
  }
  const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
  function schedule(ms=250){if(timer!==null)clearTimeout(timer);timer=setTimeout(()=>{timer=null;void check();},ms);}
  async function check() {
    if(disposed||pending||manual)return;
    const c=inspect();
    if(!c){state=null;return;}
    if(!state||state.url!==c.url||state.player!==c.player||state.video!==c.video)
      state={...c,clicks:0,failures:0,notBefore:0,clickedButton:null};
    // A newly rendered ad button starts a new bounded attempt, even when the
    // player reuses its video element across consecutive ads.
    if(state.clickedButton && state.clickedButton!==c.button)state={...c,clicks:0,failures:0,notBefore:0,clickedButton:null};
    if(!c.ready||state.clicks>=2||Date.now()<state.notBefore)return;
    pending=true;const run=state;
    try {
      const result=await chrome.runtime.sendMessage({type:'nuv-chzzk-tab-click',expectedUrl:c.url});
      if(disposed||state!==run)return;
      if(result?.code==='clicked'){run.clicks++;run.clickedButton=c.button;run.notBefore=Date.now()+1200;}
      else if(result?.code==='input_unconfirmed')run.clicks=2;
      else {run.failures++;run.notBefore=Date.now()+Math.min(5000,250*2**Math.min(run.failures,4));}
    } catch {run.notBefore=Date.now()+3000;}
    finally {pending=false;if(!disposed)schedule(Math.max(100,(state?.notBefore||0)-Date.now()));}
  }
  async function execute(message) {
    if(disposed||manual||pending)return {code:'episode_busy'};
    if(!actions.has(message.action)||message.expectedUrl!==location.href||Date.now()>=message.expiresAt)return {code:'expired'};
    const c=inspect(message.action,true);
    if(!c?.ready)return {code:'not_available'};
    manual=true;
    try {
      const result=await chrome.runtime.sendMessage({type:'nuv-chzzk-tab-click',action:message.action,requestId:message.id,expectedUrl:message.expectedUrl});
      if(result?.code!=='clicked')return {code:result?.code||'error'};
      const until=Math.min(message.expiresAt,Date.now()+1400);
      while(!disposed&&Date.now()<until) {
        if(message.action==='BrowserChzzkSkipAd') {
          if(!inspect())return {code:'ok'};
        } else if(location.href!==message.expectedUrl)return {code:'video_moved'};
        await wait(60);
      }
      return {code:message.action==='BrowserChzzkSkipAd'?'skip_unconfirmed':'video_unconfirmed'};
    } finally {manual=false;}
  }
  const listener=(m,s,reply)=>{
    if(disposed||s.id!==chrome.runtime.id)return false;
    if(m?.type==='nuv-chzzk-tab-wake') {if(state)state.notBefore=0;void check();reply({ok:true});return false;}
    if(m?.type!=='nuv-chzzk-tab-ready'||m.expectedUrl!==location.href)return false;
    const c=inspect(m.action||'BrowserChzzkSkipAd',!!m.requestId);
    reply({url:location.href,version,ready:!!c?.ready,hover:c?.hover===true,geometry:c?.geometry||null});return false;
  };
  const wake=()=>{void check();};
  chrome.runtime.onMessage.addListener(listener);
  const observer=new MutationObserver(wake);
  observer.observe(document.documentElement,{subtree:true,childList:true,attributes:true,attributeFilter:['class','style','disabled','aria-disabled','aria-label']});
  const interval=setInterval(wake,500);
  for(const e of ['timeupdate','playing','visibilitychange','fullscreenchange','transitionend'])document.addEventListener(e,wake,true);
  globalThis.NuvChzzk={version,execute,dispose(){disposed=true;observer.disconnect();clearInterval(interval);clearTimeout(timer);chrome.runtime.onMessage.removeListener(listener);for(const e of ['timeupdate','playing','visibilitychange','fullscreenchange','transitionend'])document.removeEventListener(e,wake,true);}};
  wake();
})();
