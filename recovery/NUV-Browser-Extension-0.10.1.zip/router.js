export const sites = {
  '치지직': 'https://chzzk.naver.com/*', YouTube: 'https://www.youtube.com/*', Netflix: 'https://www.netflix.com/*', 'Disney+': 'https://www.disneyplus.com/*'
};
export const actions = {
  BrowserChzzkPrevious: '치지직', BrowserChzzkNext: '치지직', BrowserChzzkSkipAd: '치지직',
  BrowserYouTubeMute: 'YouTube', BrowserYouTubeNext: 'YouTube', BrowserYouTubePrevious: 'YouTube',
  BrowserNetflixMute: 'Netflix', BrowserNetflixSkipIntro: 'Netflix',
  BrowserNetflixPreviousEpisode: 'Netflix', BrowserNetflixNextEpisode: 'Netflix',
  BrowserDisneyMute: 'Disney+', BrowserDisneySkipIntro: 'Disney+'
};
export function serviceOf(url) {
  try {
    const value = new URL(url);
    if (value.protocol !== 'https:') return null;
    return { 'chzzk.naver.com': '치지직', 'www.youtube.com': 'YouTube', 'www.netflix.com': 'Netflix', 'www.disneyplus.com': 'Disney+' }[value.hostname] ?? null;
  } catch { return null; }
}
export function selectTab(tabs, service, selectedId) {
  const matches = tabs.filter(t => Number.isInteger(t.id) && serviceOf(t.url) === service);
  if (selectedId != null) {
    const selected = matches.find(t => t.id === selectedId);
    return selected ? { tab: selected } : { code: 'no_tab' };
  }
  return matches.length === 1 ? { tab: matches[0] } : { code: matches.length ? 'ambiguous' : 'no_tab' };
}
export function validCommand(message, now = Date.now()) {
  return message?.type === 'execute' && /^[0-9a-f]{32}$/.test(message.id) &&
    Object.hasOwn(actions, message.action) && actions[message.action] === message.service &&
    Number.isSafeInteger(message.expiresAt) && message.expiresAt > now && message.expiresAt <= now + 5000;
}
