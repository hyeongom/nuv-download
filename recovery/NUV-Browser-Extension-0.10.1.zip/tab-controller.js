import { serviceOf } from './router.js';

// Restore only the chosen video tab. Never reload/navigate a page, activate it,
// or replay an execution command whose result may already have been delivered.
const preparing = new Map();
async function bounded(task,ms=900) {
  let timer;
  try{return await Promise.race([task,new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('controller_timeout')),ms);})]);}
  finally{clearTimeout(timer);}
}
export function ensureTabController(tab) {
  if (!Number.isInteger(tab?.id) || !serviceOf(tab.url)) return Promise.reject(new Error('unsupported_tab'));
  const existing = preparing.get(tab.id);
  if (existing?.url === tab.url) return existing.task;
  const entry = { url: tab.url };
  entry.task = prepare(tab).finally(() => { if (preparing.get(tab.id) === entry) preparing.delete(tab.id); });
  preparing.set(tab.id, entry);
  return entry.task;
}
async function prepare(tab) {
  const version = chrome.runtime.getManifest().version;
  const request = { type: 'nuv-probe-v2' };
  const matches = value => value?.version === version && value.url === tab.url;
  let target = { frameId: 0 };
  let probe = await bounded(chrome.tabs.sendMessage(tab.id, request, target)).catch(() => null);
  if (!matches(probe)) {
    const current = await bounded(chrome.tabs.get(tab.id));
    if (current.url !== tab.url) throw new Error('page_changed');
    // These are bundled, site-scoped content scripts; no page-supplied code/URL.
    const files = chrome.runtime.getManifest().content_scripts[0].js;
    const results = await bounded(chrome.scripting.executeScript({ target: { tabId: tab.id, frameIds: [0] }, files }),1500);
    const document = results.find(r => r.frameId === 0 && r.documentId);
    if (!document) throw new Error('controller_unavailable');
    target = { documentId: document.documentId };
    probe = await bounded(chrome.tabs.sendMessage(tab.id, request, target)).catch(() => null);
    if (!matches(probe)) throw new Error('controller_unavailable');
  }
  const current = await bounded(chrome.tabs.get(tab.id));
  if (current.url !== tab.url) throw new Error('page_changed');
  return { probe, target };
}
